
import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-investment-amount.ts';
