'use server';

/**
 * @fileOverview AI-powered donation suggestion flow.
 *
 * - suggestDonation - A function that suggests a donation amount based on user's past history.
 * - SuggestDonationInput - The input type for the suggestDonation function.
 * - SuggestDonationOutput - The return type for the suggestDonation function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestDonationInputSchema = z.object({
  userId: z.string().describe('The ID of the user.'),
  pastDonations: z
    .array(z.number())
    .describe('The user\'s past donations.'),
});
export type SuggestDonationInput = z.infer<typeof SuggestDonationInputSchema>;

const SuggestDonationOutputSchema = z.object({
  suggestedDonation: z
    .number()
    .describe('The suggested donation amount based on past history.'),
  reasoning: z
    .string()
    .describe('The reasoning behind the suggested donation amount.'),
});
export type SuggestDonationOutput = z.infer<typeof SuggestDonationOutputSchema>;

export async function suggestDonation(
  input: SuggestDonationInput
): Promise<SuggestDonationOutput> {
  return suggestDonationFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestDonationPrompt',
  input: {schema: SuggestDonationInputSchema},
  output: {schema: SuggestDonationOutputSchema},
  prompt: `You are a helpful assistant that suggests donation amounts to users based on their past history.

  Analyze the user's past donations and suggest an amount that is appropriate for them.
  Explain your reasoning for the suggested amount.

  User ID: {{{userId}}}
  Past Donations: {{{pastDonations}}}

  Suggest a donation amount and explain your reasoning.`,
});

const suggestDonationFlow = ai.defineFlow(
  {
    name: 'suggestDonationFlow',
    inputSchema: SuggestDonationInputSchema,
    outputSchema: SuggestDonationOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
