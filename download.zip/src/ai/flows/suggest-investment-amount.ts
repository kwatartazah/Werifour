
'use server';

/**
 * @fileOverview AI-powered investment suggestion flow.
 *
 * - suggestInvestment - A function that suggests an investment amount based on user's past history.
 * - SuggestInvestmentInput - The input type for the suggestInvestment function.
 * - SuggestInvestmentOutput - The return type for the suggestInvestment function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestInvestmentInputSchema = z.object({
  userId: z.string().describe('The ID of the user.'),
  pastInvestments: z
    .array(z.number())
    .describe('The user\'s past investments.'),
});
export type SuggestInvestmentInput = z.infer<typeof SuggestInvestmentInputSchema>;

const SuggestInvestmentOutputSchema = z.object({
  suggestedInvestment: z
    .number()
    .describe('The suggested investment amount based on past history.'),
  reasoning: z
    .string()
    .describe('The reasoning behind the suggested investment amount.'),
});
export type SuggestInvestmentOutput = z.infer<typeof SuggestInvestmentOutputSchema>;

export async function suggestInvestment(
  input: SuggestInvestmentInput
): Promise<SuggestInvestmentOutput> {
  return suggestInvestmentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestInvestmentPrompt',
  input: {schema: SuggestInvestmentInputSchema},
  output: {schema: SuggestInvestmentOutputSchema},
  prompt: `You are a helpful assistant that suggests investment amounts to users based on their past history.

  Analyze the user's past investments and suggest an amount that is appropriate for them.
  Explain your reasoning for the suggested amount.

  User ID: {{{userId}}}
  Past Investments: {{{pastInvestments}}}

  Suggest an investment amount and explain your reasoning.`,
});

const suggestInvestmentFlow = ai.defineFlow(
  {
    name: 'suggestInvestmentFlow',
    inputSchema: SuggestInvestmentInputSchema,
    outputSchema: SuggestInvestmentOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
