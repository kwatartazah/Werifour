
export const stats = [
  {
    title: 'Total investment',
    value: 42540000,
    change: '+12.5%',
    icon: 'DollarSign',
  },
  {
    title: 'Total members',
    value: 10254,
    change: '+21.2%',
    icon: 'Users',
  },
  {
    title: 'Available',
    value: 31449,
    change: '-2.3%',
    icon: 'Wallet',
  },
  {
    title: 'Spent',
    value: 22789,
    change: '+5.7%',
    icon: 'CreditCard',
  },
  {
    title: 'My total share',
    value: 1234,
    change: '2.3%',
    icon: 'User',
  },
  {
    title: 'Subscribed members',
    value: 9150,
    change: '+5.2%',
    icon: 'UserCheck',
  },
].map(stat => ({ ...stat, originalTitle: stat.title }));

const generateWeeklyData = () => {
  const data = []
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
  for (let i = 0; i < 7; i++) {
    data.push({
      date: days[i],
      investment: Math.floor(Math.random() * 1000) + 200,
      services: Math.floor(Math.random() * 800) + 100,
    })
  }
  return data
}


const generateMonthlyData = () => {
  const data = []
  const today = new Date()
  const currentMonth = today.getMonth()
  const months = [
    'Jan',
    'Feb',

    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ]
  for (let i = 0; i < 12; i++) {
    data.push({
      date: months[i],
      investment:
        i <= currentMonth ? Math.floor(Math.random() * 5000) + 1000 : 0,
      services:
        i <= currentMonth ? Math.floor(Math.random() * 4000) + 800 : 0,
    })
  }
  return data
}

const generateYearlyData = () => {
  const data = []
  const currentYear = new Date().getFullYear()
  for (let i = -2; i < 3; i++) {
    const year = currentYear + i
    data.push({
      date: `${year}`,
      investment:
        year < currentYear ? Math.floor(Math.random() * 20000) + 5000 : (year === currentYear ? 25000 : 0),
      services:
        year < currentYear ? Math.floor(Math.random() * 15000) + 4000 : (year === currentYear ? 18000 : 0),
    })
  }
  return data
}

export const chartData = {
  week: generateWeeklyData(),
  month: generateMonthlyData(),
  year: generateYearlyData(),
}

export type ChartDataKey = keyof typeof chartData

export const pastInvestments = [10, 25, 15, 50, 20];

export const paymentHistory = [
  { id: 'pay_1', date: '2024-07-15', amount: 50, type: 'One-Time', status: 'Paid' },
  { id: 'pay_2', date: '2024-07-10', amount: 25, type: 'Monthly', status: 'Paid' },
  { id: 'pay_3', date: '2024-06-20', amount: 100, type: 'One-Time', status: 'Paid' },
  { id: 'pay_4', date: '2024-06-10', amount: 25, type: 'Monthly', status: 'Paid' },
  { id: 'pay_5', date: '2024-05-25', amount: 75, type: 'One-Time', status: 'Failed' },
  { id: 'pay_6', date: '2024-05-10', amount: 25, type: 'Monthly', status: 'Paid' },
];
