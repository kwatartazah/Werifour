
export const translations = {
  en: {
    header: {
        title: "werifour"
    },
    nav: {
      home: "Home",
      services: "Services",
      members: "Members",
      actions: "Actions",
      account: "Account"
    },
    home: {
      tabs: {
        overview: "Overview",
        invest: "Invest",
        analytics: "Analytics"
      }
    },
    accountMenu: {
      myAccount: "My Account",
      settings: "Settings",
      language: "Language",
      support: "Support",
      logout: "Logout",
      languages: {
        english: "English",
        arabic: "Arabic"
      }
    },
    login: {
      title: "Login",
      description: "Enter your credentials below to login to your account.",
      button: "Login",
      tabs: {
        email: "Email",
        phone: "Phone"
      },
      toast: {
        success: {
          title: "Login Successful",
          description: "Welcome back!",
        },
        failure: {
            title: "Login Failed",
            description: "Invalid credentials. Please try again.",
            descriptionCode: "Invalid details or confirmation code. Please try again.",
        }
      },
      noAccount: "Don't have an account?",
      registerLink: "Register",
      forgotPassword: {
        link: "Forgot Password?",
        sendCodeButton: "Send Confirmation Code",
        codeLabel: "Confirmation Code",
        loginWithPasswordLink: "Login with password",
        toast: {
            notFound: {
                title: "User Not Found",
                description: "No account found with this email/phone number."
            },
            invalid: {
                title: "Invalid Input",
                description: "Please enter a valid {type} address."
            }
        }
      }
    },
    register: {
      title: "Register",
      description: "Create your account to get started.",
      button: "Create Account",
      confirmPassword: "Confirm Password",
      username: "Username",
      firstName: "First Name",
      lastName: "Last Name",
      toast: {
        title: "Registration Successful!",
        description: "Your account has been created. Please log in.",
      },
      placeholders: {
        username: "Enter your username",
        firstName: "Enter your first name",
        lastName: "Enter your last name"
      },
      hasAccount: "Already have an account?",
      loginLink: "Login",
      validation: {
        memberName: {
            invalid: "Member name must be 4 to 20 characters and contain no spaces"
        },
        username: {
          invalid: "Username must be 4 to 20 characters and contain no spaces"
        }
      },
      gender: {
        label: "Gender",
        male: "Male",
        female: "Female"
      }
    },
    myDetails: {
      title: "My Details",
      description: "Review your personal information.",
      username: "Username",
      email: "Email",
      saveButton: "Save Changes",
      toast: {
        title: "Details Updated",
        description: "Your information has been successfully saved.",
      },
      memberId: "Member ID",
      memberName: "Member Name",
      phoneNumber: "Phone Number",
      password: "Password",
      country: "Country",
      countryPlaceholder: "Select a country",
      sendCode: "Send Code",
      sendCodeToast: {
        title: "Code Sent",
        description: "A confirmation code has been sent to your {type}.",
        descriptionWithCode: "Your confirmation code for {type} is: {code}",
        email: "email",
        phone: "phone"
      },
      verifyCodeToast: {
        title: "Verified!",
        description: "Your {type} has been successfully verified.",
      },
      logoutToast: {
        title: "Logged Out",
        description: "You have been successfully logged out.",
      },
      verify: "Verify",
      confirmationCode: "Confirmation Code",
      validation: {
        password: {
            length: "Password must be between 8 and 20 characters.",
            uppercase: "Password must contain at least one uppercase letter.",
            lowercase: "Password must contain at least one lowercase letter.",
            number: "Password must contain at least one number.",
            symbol: "Password must contain at least one special character.",
            note: "Must be 8-20 characters long, with uppercase, lowercase, number, and symbol.",
        }
      },
      updateDialog: {
        changeButton: "Change",
        saveButton: "Save",
        cancelButton: "Cancel",
        title: "Change {field}",
        description: "Enter the new value for your {field}.",
        toast: {
            title: "Field Updated",
            description: "{field} has been successfully updated."
        },
        fields: {
            memberName: "Member Name",
            email: "Email",
            phoneNumber: "Phone Number",
            password: "Password",
            country: "Country",
        }
      },
      support: {
        title: "Contact Support",
        description: "Need help? Contact our support team.",
        button: "Contact",
        formDescription: "Please fill out the form below and we will get back to you as soon as possible.",
        namePlaceholder: "Your Name",
        emailPlaceholder: "Your Email",
        messagePlaceholder: "Your Message",
        submitButton: "Submit",
        helpLink: "Help",
        toast: {
          title: "Message Sent!",
          description: "Our support team has received your message and will get back to you shortly.",
        }
      }
    },
    stats: {
        totalinvestment: "Total investment",
        totalmembers: "Total members",
        available: "Available",
        spent: "Spent",
        mytotalshare: "My total share",
        subscribedmembers: "Subscribed members",
    },
    statCard: {
        description: {
            myTotalShare: "{change} of total investment",
            lastMonth: "{change} from last month"
        }
    },
    investmentForm: {
        title: "Make an Investment",
        description: "Choose a monthly subscription or make a one-time investment.",
        tabs: {
            monthly: "Monthly",
            oneTime: "One-Time"
        },
        monthly: {
            prompt: "Select a monthly tier for ongoing investments.",
            month: "month",
            subscribeButton: "Subscribe for {amount}/month"
        },
        oneTime: {
            customAmount: "Custom Amount",
            investButton: "Invest {amount}"
        },
        toast: {
            title: "Investment Submitted!",
            description: "Thank you for your {type} investment of {amount}.",
            monthly: "monthly",
            "one-time": "one-time",
            card: "card"
        }
    },
    analyticsChart: {
        investment: "Investment",
        services: "Services",
        week: "Week",
        month: "Month",
        year: "Year",
        investmentTitle: "Investment Analytics",
        investmentDescription: "Aggregated investment trends over time."
    },
    actions: {
        tabs: {
            opinions: "Opinions",
            tasks: "Tasks",
            vote: "Vote"
        },
        news: {
            create: {
                title: "Create a post",
                description: "Share your thoughts with the community. Your post will be visible for 24 hours.",
                messageLabel: "Your Message",
                cancel: "Cancel",
                post: "Post"
            },
            toast: {
                limit: {
                    title: "Post limit reached",
                    description: "You can only have one active post at a time.",
                }
            }
        },
        vote: {
            title: "Community Project Vote",
            description: "We are asking all {totalMembers} members to vote on whether we should proceed with the new community project. Please cast your vote below.",
            resultsTitle: "Voting Results",
            resultsDescription: "Current results from all members.",
            yes: "Yes",
            no: "No",
        }
    },
    services: {
      tabs: {
        services: "Services",
        analytics: "Analytics",
        breakdown: "Breakdown"
      }
    },
    members: {
      tabs: {
        members: "Members",
        countries: "Members by countries",
        countryList: "Countries",
        breakdown: "Breakdown"
      }
    }
  },
  ar: {
    header: {
        title: "ويريفور"
    },
    nav: {
        home: "الرئيسية",
        services: "الخدمات",
        members: "الأعضاء",
        actions: "الإجراءات",
        account: "الحساب"
    },
    home: {
      tabs: {
        overview: "نظرة عامة",
        invest: "استثمار",
        analytics: "التحليلات"
      }
    },
    accountMenu: {
        myAccount: "حسابي",
        settings: "الإعدادات",
        language: "اللغة",
        support: "الدعم",
        logout: "تسجيل الخروج",
        languages: {
            english: "الإنجليزية",
            arabic: "العربية"
        }
    },
    login: {
        title: "تسجيل الدخول",
        description: "أدخل بياناتك أدناه لتسجيل الدخول إلى حسابك.",
        button: "تسجيل الدخول",
        tabs: {
            email: "البريد الإلكتروني",
            phone: "رقم الهاتف"
        },
        toast: {
            success: {
                title: "تم تسجيل الدخول بنجاح",
                description: "مرحبًا بعودتك!",
            },
            failure: {
                title: "فشل تسجيل الدخول",
                description: "بيانات الاعتماد غير صالحة. يرجى المحاولة مرة أخرى.",
                descriptionCode: "تفاصيل أو رمز تأكيد غير صالح. يرجى المحاولة مرة أخرى.",
            }
        },
        noAccount: "ليس لديك حساب؟",
        registerLink: "التسجيل",
        forgotPassword: {
            link: "هل نسيت كلمة المرور؟",
            sendCodeButton: "إرسال رمز التأكيد",
            codeLabel: "رمز التأكيد",
            loginWithPasswordLink: "تسجيل الدخول بكلمة المرور",
            toast: {
                notFound: {
                    title: "المستخدم غير موجود",
                    description: "لم يتم العثور على حساب بهذا البريد الإلكتروني/رقم الهاتف."
                },
                invalid: {
                    title: "إدخال غير صالح",
                    description: "الرجاء إدخال {type} صالح."
                }
            }
        }
    },
    register: {
        title: "التسجيل",
        description: "أنشئ حسابك للبدء.",
        button: "إنشاء حساب",
        confirmPassword: "تأكيد كلمة المرور",
        username: "اسم المستخدم",
        firstName: "الاسم الأول",
        lastName: "اسم العائلة",
        toast: {
            title: "تم التسجيل بنجاح!",
            description: "تم إنشاء حسابك. يرجى تسجيل الدخول.",
        },
        placeholders: {
            username: "أدخل اسم المستخدم الخاص بك",
            firstName: "أدخل اسمك الأول",
            lastName: "أدخل اسم عائلتك"
        },
        hasAccount: "هل لديك حساب بالفعل؟",
        loginLink: "تسجيل الدخول",
        validation: {
            memberName: {
                invalid: "يجب أن يتراوح طول اسم العضو بين 4 و 20 حرفًا وألا يحتوي على مسافات"
            },
            username: {
                invalid: "يجب أن يتراوح اسم المستخدم بين 4 و 20 حرفًا وألا يحتوي على مسافات"
            }
        },
        gender: {
            label: "الجنس",
            male: "ذكر",
            female: "أنثى"
        }
    },
    myDetails: {
        title: "تفاصيلي",
        description: "مراجعة معلوماتك الشخصية.",
        username: "اسم المستخدم",
        email: "البريد الإلكتروني",
        saveButton: "حفظ التغييرات",
        toast: {
            title: "تم تحديث التفاصيل",
            description: "تم حفظ معلوماتك بنجاح.",
        },
        memberId: "معرف العضو",
        memberName: "اسم العضو",
        phoneNumber: "رقم الهاتف",
        password: "كلمة المرور",
        country: "البلد",
        countryPlaceholder: "اختر دولة",
        sendCode: "إرسال الرمز",
        sendCodeToast: {
            title: "تم إرسال الرمز",
            description: "تم إرسال رمز تأكيد إلى {type} الخاص بك.",
            descriptionWithCode: "رمز التأكيد الخاص بك لـ {type} هو: {code}",
            email: "البريد الإلكتروني",
            phone: "الهاتف"
        },
        verifyCodeToast: {
            title: "تم التحقق!",
            description: "تم التحقق من {type} الخاص بك بنجاح.",
        },
        logoutToast: {
            title: "تم تسجيل الخروج",
            description: "لقد تم تسجيل خروجك بنجاح.",
        },
        verify: "تحقق",
        confirmationCode: "رمز التأكيد",
        validation: {
            password: {
                length: "يجب أن تكون كلمة المرور بين 8 و 20 حرفًا.",
                uppercase: "يجب أن تحتوي كلمة المرور على حرف كبير واحد على الأقل.",
                lowercase: "يجب أن تحتوي كلمة المرور على حرف صغير واحد على الأقل.",
                number: "يجب أن تحتوي كلمة المرور على رقم واحد على الأقل.",
                symbol: "يجب أن تحتوي كلمة المرور على رمز خاص واحد على الأقل.",
                note: "يجب أن يتراوح طوله بين 8-20 حرفًا ، مع وجود أحرف كبيرة وصغيرة ورقم ورمز."
            }
        },
        updateDialog: {
            changeButton: "تغيير",
            saveButton: "حفظ",
            cancelButton: "إلغاء",
            title: "تغيير {field}",
            description: "أدخل القيمة الجديدة لـ {field} الخاص بك.",
            toast: {
                title: "تم تحديث الحقل",
                description: "تم تحديث {field} بنجاح."
            },
            fields: {
                memberName: "اسم العضو",
                email: "البريد الإلكتروني",
                phoneNumber: "رقم الهاتف",
                password: "كلمة المرور",
                country: "البلد"
            }
        },
        support: {
            title: "الاتصال بالدعم",
            description: "هل تحتاج إلى مساعدة؟ اتصل بفريق الدعم لدينا.",
            button: "اتصل",
            formDescription: "يرجى ملء النموذج أدناه وسنعود إليك في أقرب وقت ممكن.",
            namePlaceholder: "اسمك",
            emailPlaceholder: "بريدك الإلكتروني",
            messagePlaceholder: "رسالتك",
            submitButton: "إرسال",
            helpLink: "مساعدة",
            toast: {
              title: "تم إرسال الرسالة!",
              description: "تلقى فريق الدعم لدينا رسالتك وسيعود إليك قريبًا.",
            }
        }
    },
    stats: {
        totalinvestment: "إجمالي الاستثمار",
        totalmembers: "إجمالي الأعضاء",
        available: "المتاح",
        spent: "أنفق",
        mytotalshare: "إجمالي حصتي",
        subscribedmembers: "الأعضاء المشتركون",
    },
    statCard: {
        description: {
            myTotalShare: "{change} من إجمالي الاستثمار",
            lastMonth: "{change} عن الشهر الماضي"
        }
    },
    investmentForm: {
        title: "قم باستثمار",
        description: "اختر اشتراكًا شهريًا أو قم باستثمار لمرة واحدة.",
        tabs: {
            monthly: "شهري",
            oneTime: "مرة واحدة"
        },
        monthly: {
            prompt: "حدد فئة شهرية للاستثمارات المستمرة.",
            month: "شهر",
            subscribeButton: "اشترك مقابل {amount}/شهر"
        },
        oneTime: {
            customAmount: "م مبلغ مخصص",
            investButton: "استثمر {amount}"
        },
        toast: {
            title: "تم تقديم الاستثمار!",
            description: "شكرًا لك على استثمارك {type} بمبلغ {amount}.",
            monthly: "شهري",
            "one-time": "لمرة واحدة",
            card: "بالبطاقة"
        }
    },
    analyticsChart: {
        investment: "الاستثمار",
        services: "الخدمات",
        week: "أسبوع",
        month: "شهر",
        year: "سنة",
        investmentTitle: "تحليلات الاستثمار",
        investmentDescription: "اتجاهات الاستثمار المجمعة مع مرور الوقت."
    },
    actions: {
        tabs: {
            opinions: "آراء",
            tasks: "المهام",
            vote: "تصويت"
        },
        news: {
            create: {
                title: "إنشاء منشور",
                description: "شارك بأفكارك مع المجتمع. سيكون منشورك مرئيًا لمدة 24 ساعة.",
                messageLabel: "رسالتك",
                cancel: "إلغاء",
                post: "نشر"
            },
            toast: {
                limit: {
                    title: "تم الوصول إلى حد المنشورات",
                    description: "يمكنك فقط الحصول على منشور واحد نشط في كل مرة.",
                }
            }
        },
        vote: {
            title: "تصويت على مشروع المجتمع",
            description: "نطلب من جميع الأعضاء البالغ عددهم {totalMembers} التصويت على ما إذا كان يجب علينا المضي قدمًا في مشروع المجتمع الجديد. يرجى الإدلاء بصوتك أدناه.",
            resultsTitle: "نتائج التصويت",
            resultsDescription: "النتائج الحالية من جميع الأعضاء.",
            yes: "نعم",
            no: "لا"
        }
    },
    services: {
      tabs: {
        services: "الخدمات",
        analytics: "التحليلات",
        breakdown: "التفصيل"
      }
    },
    members: {
      tabs: {
        members: "الأعضاء",
        countries: "الأعضاء حسب البلدان",
        countryList: "البلدان",
        breakdown: "التفصيل"
      }
    }
  }
};
