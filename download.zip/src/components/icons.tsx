
export function ThumbsUpIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M7 10v12" />
      <path d="M18 10V4a2 2 0 0 0-2-2H8.5a2.5 2.5 0 0 0-2.36 1.63L5 10v12h13a2 2 0 0 0 2-2V12a2 2 0 0 0-2-2h-2" />
    </svg>
  );
}

export function ThumbsDownIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M17 14V2" />
      <path d="M6 14v10a2 2 0 0 0 2 2h8.5a2.5 2.5 0 0 0 2.36-1.63L21 14V2H8a2 2 0 0 0-2 2v10" />
    </svg>
  );
}
