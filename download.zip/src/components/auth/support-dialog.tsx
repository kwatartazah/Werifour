
'use client';

import React, { useState } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { LifeBuoy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTranslation } from '@/hooks/use-translation';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { FormControl, FormField, FormItem, FormMessage } from '@/components/ui/form';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';

const supportSchema = z.object({
    name: z.string().min(1, 'Name is required'),
    email: z.string().email('Invalid email address'),
    message: z.string().min(1, 'Message is required'),
});

export function SupportDialog() {
    const { t } = useTranslation();
    const [isOpen, setIsOpen] = useState(false);
    const { toast } = useToast();
    const form = useForm({
        resolver: zodResolver(supportSchema),
        defaultValues: { name: '', email: '', message: '' }
    });

    const onSubmit = (data: any) => {
        toast({
            title: t('myDetails.support.toast.title'),
            description: t('myDetails.support.toast.description'),
        });
        setIsOpen(false);
        form.reset();
    };

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
                 <button className="font-semibold text-primary hover:underline">{t('myDetails.support.helpLink')}</button>
            </DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{t('myDetails.support.title')}</DialogTitle>
                    <DialogDescription>{t('myDetails.support.formDescription')}</DialogDescription>
                </DialogHeader>
                <FormProvider {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                        <ControlledInput name="name" placeholder={t('myDetails.support.namePlaceholder')} />
                        <ControlledInput name="email" type="email" placeholder={t('myDetails.support.emailPlaceholder')} />
                        <FormField
                            name="message"
                            render={({ field }) => (
                                <FormItem>
                                    <FormControl>
                                        <Textarea placeholder={t('myDetails.support.messagePlaceholder')} {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <DialogFooter>
                            <DialogClose asChild>
                                <Button type="button" variant="ghost">{t('myDetails.updateDialog.cancelButton')}</Button>
                            </DialogClose>
                            <Button type="submit">{t('myDetails.support.submitButton')}</Button>
                        </DialogFooter>
                    </form>
                </FormProvider>
            </DialogContent>
        </Dialog>
    );
}

export function ControlledInput({ name, ...props }: { name: string } & React.ComponentProps<typeof Input>) {
    return (
        <FormField
            name={name}
            render={({ field }) => (
                <FormItem>
                    <FormControl>
                        <Input {...field} {...props} />
                    </FormControl>
                    <FormMessage />
                </FormItem>
            )}
        />
    )
}

    