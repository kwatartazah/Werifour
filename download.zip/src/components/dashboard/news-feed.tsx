
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ThumbsDown, ThumbsUp, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface NewsItem {
  id: number;
  author: string;
  content: string;
  timestamp: Date;
  likes: number;
  dislikes: number;
  textAlign?: 'left' | 'right';
}

type NewsFeedProps = {
    newsItems: NewsItem[];
    setNewsItems: React.Dispatch<React.SetStateAction<NewsItem[]>>;
};

type VoteStatus = 'liked' | 'disliked' | null;

export function NewsFeed({ newsItems, setNewsItems }: NewsFeedProps) {
    const [currentTime, setCurrentTime] = useState(new Date());
    const [voteState, setVoteState] = useState<{[key: number]: VoteStatus}>({});

    const getRemainingTime = (timestamp: Date) => {
      const twentyFourHours = 24 * 60 * 60 * 1000;
      const postAge = Date.now() - timestamp.getTime();
      const remainingTime = twentyFourHours - postAge;
  
      if (remainingTime <= 0) {
          return '00:00:00';
      }
  
      const hours = Math.floor((remainingTime / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((remainingTime / 1000 / 60) % 60);
      const seconds = Math.floor((remainingTime / 1000) % 60);
  
      return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    };

    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentTime(new Date());

            const updatedNewsItems = newsItems.filter(item => {
                const twentyFourHours = 24 * 60 * 60 * 1000;
                const postAge = Date.now() - item.timestamp.getTime();
                return postAge < twentyFourHours;
            });

            if(updatedNewsItems.length !== newsItems.length) {
                setNewsItems(updatedNewsItems);
            }
        }, 1000);

        return () => clearInterval(timer);
    }, [newsItems, setNewsItems]);

    const handleVote = (itemId: number, newVote: 'liked' | 'disliked') => {
      const currentVote = voteState[itemId];
      
      setNewsItems(prevItems => prevItems.map(item => {
        if (item.id !== itemId) return item;

        let newLikes = item.likes;
        let newDislikes = item.dislikes;

        if (currentVote === newVote) { // Withdraw vote
          if (newVote === 'liked') newLikes--;
          else newDislikes--;
          setVoteState(prev => ({ ...prev, [itemId]: null }));
        } else { // New vote or changing vote
          if (currentVote === 'liked') newLikes--;
          if (currentVote === 'disliked') newDislikes--;

          if (newVote === 'liked') newLikes++;
          else newDislikes++;
          setVoteState(prev => ({ ...prev, [itemId]: newVote }));
        }
        
        return { ...item, likes: newLikes, dislikes: newDislikes };
      }));
    }

    if (newsItems.length === 0) {
        return <p className="text-center text-muted-foreground">No news yet. Check back later!</p>;
    }

  return (
    <div className="space-y-4">
      {newsItems.map((item) => (
        <Card key={item.id}>
          <CardContent className="p-4">
            <div className="flex space-x-4">
              <div className="flex-1">
                <div className="flex items-center justify-between">
                    <span className="font-bold">{item.author}</span>
                    <div className="flex items-center text-xs text-muted-foreground">
                        <Clock className="mr-1 h-3 w-3" />
                        <span>{getRemainingTime(item.timestamp)}</span>
                    </div>
                </div>
                <p className={cn("mt-2 text-sm break-words overflow-hidden", item.textAlign === 'right' ? 'text-right' : 'text-left')}>{item.content}</p>
                <div className="flex justify-end items-center mt-4 text-muted-foreground space-x-4">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className={cn(
                      "flex items-center space-x-2",
                      voteState[item.id] === 'liked' ? 'text-green-500' : 'hover:text-green-500'
                    )}
                    onClick={() => handleVote(item.id, 'liked')}
                  >
                    <ThumbsUp className="h-4 w-4" />
                    <span>{item.likes}</span>
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className={cn(
                      "flex items-center space-x-2",
                      voteState[item.id] === 'disliked' ? 'text-red-500' : 'hover:text-red-500'
                    )}
                    onClick={() => handleVote(item.id, 'disliked')}
                  >
                    <ThumbsDown className="h-4 w-4" />
                    <span>{item.dislikes}</span>
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
