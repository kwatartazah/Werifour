
'use client'

import React, { useState, useTransition } from 'react'
import { Wand2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { getInvestmentSuggestion } from '@/app/actions'
import { pastInvestments } from '@/lib/data'
import { useToast } from '@/hooks/use-toast'
import { Skeleton } from '@/components/ui/skeleton'

type Suggestion = {
  suggestedInvestment?: number
  reasoning?: string
  error?: string
}

export function AiSuggestion({
  onSuggestionSelect,
}: {
  onSuggestionSelect: (amount: number) => void
}) {
  const [isOpen, setIsOpen] = useState(false)
  const [suggestion, setSuggestion] = useState<Suggestion | null>(null)
  const [isPending, startTransition] = useTransition()
  const { toast } = useToast()

  const handleGetSuggestion = () => {
    setIsOpen(true)
    setSuggestion(null) // Reset previous suggestion
    startTransition(async () => {
      const result = await getInvestmentSuggestion({
        userId: 'user-123', // Mock user ID
        pastInvestments: pastInvestments,
      })
      if (result.error) {
        toast({
          variant: 'destructive',
          title: 'AI Suggestion Failed',
          description: result.error,
        })
        setIsOpen(false)
      } else {
        setSuggestion(result)
      }
    })
  }

  const handleAcceptSuggestion = () => {
    if (suggestion?.suggestedInvestment) {
      onSuggestionSelect(suggestion.suggestedInvestment)
      setIsOpen(false)
    }
  }

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        onClick={handleGetSuggestion}
        className="w-full"
      >
        <Wand2 className="mr-2 h-4 w-4" />
        AI Suggestion
      </Button>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>AI-Powered Investment Suggestion</DialogTitle>
            <DialogDescription>
              Let our AI analyze your history to suggest a meaningful
              investment amount.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {isPending || !suggestion ? (
              <div className="space-y-4">
                <Skeleton className="h-8 w-1/2 rounded-lg" />
                <Skeleton className="h-4 w-full rounded-lg" />
                <Skeleton className="h-4 w-4/5 rounded-lg" />
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-4xl font-bold text-primary font-headline">
                  {suggestion.suggestedInvestment}
                </p>
                <p className="text-sm text-muted-foreground">
                  {suggestion.reasoning}
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleAcceptSuggestion}
              disabled={isPending || !suggestion?.suggestedInvestment}
            >
              Use this amount
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
