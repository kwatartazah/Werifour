
'use client'

import React, { useState } from 'react'
import { Bar, BarChart, CartesianGrid, XAxis, LabelList } from 'recharts'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartConfig,
} from '@/components/ui/chart'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { chartData, type ChartDataKey } from '@/lib/data'
import { useTranslation } from '@/hooks/use-translation'
import { formatNumber } from '@/lib/utils'

type AnalyticsChartProps = {
  title: string;
  description: string;
  dataKey: "investment" | "services";
}

export function AnalyticsChart({ title, description, dataKey }: AnalyticsChartProps) {
  const [timeframe, setTimeframe] = useState<ChartDataKey>('week')
  const { t } = useTranslation();
  
  const chartConfig = {
    investment: {
      label: t('analyticsChart.investment'),
      color: 'hsl(var(--primary))',
    },
    services: {
      label: t('analyticsChart.services'),
      color: 'hsl(var(--accent))',
    }
  } satisfies ChartConfig

  const currentChartConfig = {
    [dataKey]: chartConfig[dataKey]
  }

  const renderChart = (data: typeof chartData[ChartDataKey]) => (
    <BarChart accessibilityLayer data={data} margin={{ top: 20, left: 10, right: 10, bottom: 8 }}>
      <CartesianGrid vertical={false} strokeDasharray="3 3" />
      <XAxis
        dataKey="date"
        tickLine={false}
        tickMargin={10}
        axisLine={false}
        stroke="hsl(var(--muted-foreground))"
        fontSize={12}
      />
      <ChartTooltip
        cursor={false}
        content={<ChartTooltipContent indicator="dot" />}
      />
      <Bar
        dataKey={dataKey}
        fill={`var(--color-${dataKey})`}
        radius={[4, 4, 0, 0]}
      >
        <LabelList
            dataKey={dataKey}
            position="top"
            offset={8}
            className="fill-foreground"
            fontSize={12}
            formatter={(value: number) => formatNumber(value)}
        />
      </Bar>
    </BarChart>
  )

  return (
    <Card>
      <CardHeader className="flex flex-col items-start gap-4">
        <div className="space-y-1">
          <CardTitle>{title}</CardTitle>
          <CardDescription>
            {description}
          </CardDescription>
        </div>
        <Tabs
          defaultValue={timeframe}
          onValueChange={value => setTimeframe(value as ChartDataKey)}
          className="w-full sm:w-auto"
        >
          <TabsList className="w-full sm:w-auto">
            <TabsTrigger value="week">{t('analyticsChart.week')}</TabsTrigger>
            <TabsTrigger value="month">{t('analyticsChart.month')}</TabsTrigger>
            <TabsTrigger value="year">{t('analyticsChart.year')}</TabsTrigger>
          </TabsList>
        </Tabs>
      </CardHeader>
      <CardContent className="p-0">
          <ChartContainer
            config={currentChartConfig}
            className="h-[250px] w-full"
          >
            {renderChart(chartData[timeframe])}
          </ChartContainer>
      </CardContent>
    </Card>
  )
}
