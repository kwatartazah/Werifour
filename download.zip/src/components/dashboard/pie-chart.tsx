
'use client'

import React from 'react'
import { PieChart, Pie, Cell, Legend, ResponsiveContainer } from 'recharts'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { formatNumber } from '@/lib/utils';

const COLORS = [
    'hsl(var(--chart-1))',
    'hsl(var(--chart-2))',
    'hsl(var(--chart-3))',
    'hsl(var(--chart-4))',
    'hsl(var(--chart-5))',
    '#82ca9d',
    '#ffc658',
    '#ff8042',
];

const RADIAN = Math.PI / 180;

const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, name, value }: any) => {
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  const percentage = (percent * 100);

  const baseFontSize = 8;
  const scaleFactor = 16;
  const fontSize = Math.min(baseFontSize + (percentage / 100) * scaleFactor, 24);

  return (
    <text
      x={x}
      y={y}
      fill="white"
      textAnchor="middle"
      dominantBaseline="central"
      style={{ fontSize: `${fontSize}px`, fontWeight: 'bold', pointerEvents: 'none' }}
    >
      <tspan x={x} dy="-1em">{name}</tspan>
      <tspan x={x} dy="1.2em">{`${percentage.toFixed(0)}%`}</tspan>
      <tspan x={x} dy="1.2em">{formatNumber(value)}</tspan>
    </text>
  );
};


type PieChartComponentProps = {
  title?: string;
  description?: string;
  data: any[];
  dataKey: string;
  nameKey: string;
  hasCard?: boolean;
}

export function PieChartComponent({ title, description, data, dataKey, nameKey, hasCard = true }: PieChartComponentProps) {
  const chart = (
    <ResponsiveContainer width="100%" height={300}>
        <PieChart>
        <Pie
            data={data}
            dataKey={dataKey}
            nameKey={nameKey}
            cx="50%"
            cy="50%"
            labelLine={false}
            label={renderCustomizedLabel}
            outerRadius={100}
            innerRadius={60}
            fill="#8884d8"
        >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.fill || COLORS[index % COLORS.length]} />
            ))}
        </Pie>
        <Legend wrapperStyle={{fontSize: '12px', marginTop: '20px'}}/>
        </PieChart>
    </ResponsiveContainer>
  );

  if (!hasCard) {
    return chart;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>
          {description}
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        {chart}
      </CardContent>
    </Card>
  )
}
