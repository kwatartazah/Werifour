
'use client'

import React, { useState } from 'react'
import { Heart, CreditCard, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useToast } from '@/hooks/use-toast'
import { useTranslation } from '@/hooks/use-translation'
import { AiSuggestion } from './ai-suggestion'

const monthlyOptions = [10, 25, 50]

type InvestmentStep = 'selection' | 'payment';
type InvestmentType = 'monthly' | 'one-time';

export function InvestmentForm() {
  const [step, setStep] = useState<InvestmentStep>('selection');
  const [investmentDetails, setInvestmentDetails] = useState<{ type: InvestmentType; amount: number | string } | null>(null);

  const [monthlyAmount, setMonthlyAmount] = useState(25)
  const [oneTimeAmount, setOneTimeAmount] = useState<number | string>(50)
  const { toast } = useToast()
  const { t } = useTranslation()

  const handleOneTimeAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    if (value === '' || (Number(value) > 0 && !isNaN(Number(value)))) {
      setOneTimeAmount(value)
    }
  }

  const handleSuggestionSelect = (amount: number) => {
    setOneTimeAmount(amount)
  }

  const handleProceedToPayment = (type: InvestmentType) => {
    const amount = type === 'monthly' ? monthlyAmount : oneTimeAmount;
    setInvestmentDetails({ type, amount });
    setStep('payment');
  }

  const handlePaymentSubmit = () => {
    if (!investmentDetails) return;
    toast({
      title: t('investmentForm.toast.title'),
      description: t('investmentForm.toast.description', { type: 'card', amount: investmentDetails.amount }),
    })
    setStep('selection');
    setInvestmentDetails(null);
  }

  const handleBack = () => {
    setStep('selection');
    setInvestmentDetails(null);
  }
  
  const getTitle = () => {
    if (step === 'payment' && investmentDetails) {
        const typeText = investmentDetails.type === 'monthly' ? 'Monthly' : 'One-Time';
        return `Pay ${typeText} Investment`;
    }
    return t('investmentForm.title');
  }

  const getDescription = () => {
      if (step === 'payment' && investmentDetails) {
        return `You are about to make a ${investmentDetails.type === 'monthly' ? 'monthly subscription of' : 'one-time investment of'} ${investmentDetails.amount}. Please enter your payment details.`;
      }
      return t('investmentForm.description');
  }


  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-4">
            {step === 'payment' && (
                <Button variant="ghost" size="icon" onClick={handleBack} className="h-8 w-8">
                    <ArrowLeft className="h-5 w-5" />
                </Button>
            )}
            <div className="flex-1">
                <CardTitle>{getTitle()}</CardTitle>
                <CardDescription>{getDescription()}</CardDescription>
            </div>
        </div>
      </CardHeader>
      <CardContent>
        {step === 'selection' ? (
          <Tabs defaultValue="monthly" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="monthly">{t('investmentForm.tabs.monthly')}</TabsTrigger>
              <TabsTrigger value="one-time">{t('investmentForm.tabs.oneTime')}</TabsTrigger>
            </TabsList>
            <TabsContent value="monthly" className="mt-6">
              <div className="space-y-6">
                <p className="text-sm text-center text-muted-foreground">
                  {t('investmentForm.monthly.prompt')}
                </p>
                <div className="grid grid-cols-3 gap-4">
                  {monthlyOptions.map(amount => (
                    <Button
                      key={amount}
                      variant={monthlyAmount === amount ? 'gradient-active' : 'gradient'}
                      onClick={() => setMonthlyAmount(amount)}
                      className="h-20 flex-col"
                    >
                      <span className="text-2xl font-bold font-headline">
                        {amount}
                      </span>
                      <span className="text-xs">/{t('investmentForm.monthly.month')}</span>
                    </Button>
                  ))}
                </div>
                <Button
                  onClick={() => handleProceedToPayment('monthly')}
                  className="w-full"
                  variant="gradient"
                >
                  <Heart className="mr-2 h-4 w-4" /> {t('investmentForm.monthly.subscribeButton', { amount: monthlyAmount })}
                </Button>
              </div>
            </TabsContent>
            <TabsContent value="one-time" className="mt-6">
              <div className="space-y-6">
                <div className="grid gap-2">
                  <Label htmlFor="one-time-amount">{t('investmentForm.oneTime.customAmount')}</Label>
                  <div className="relative">
                    <Input
                      id="one-time-amount"
                      type="number"
                      placeholder="50"
                      value={oneTimeAmount}
                      onChange={handleOneTimeAmountChange}
                      className="pl-7 text-lg font-bold font-headline"
                    />
                  </div>
                </div>
                <AiSuggestion onSuggestionSelect={handleSuggestionSelect} />
                <Button
                  onClick={() => handleProceedToPayment('one-time')}
                  className="w-full"
                  variant="gradient"
                >
                  <Heart className="mr-2 h-4 w-4" /> {t('investmentForm.oneTime.investButton', { amount: oneTimeAmount || 0 })}
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        ) : (
            <CardPaymentForm onSubmit={handlePaymentSubmit} />
        )}
      </CardContent>
    </Card>
  )
}

function CardPaymentForm({ onSubmit }: { onSubmit: () => void }) {
  const [cardData, setCardData] = useState({
    name: '',
    number: '',
    expiry: '',
    cvc: '',
  });
  const [isFlipped, setIsFlipped] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    
    if (name === 'number') {
        const cleanedValue = value.replace(/\D/g, '');
        const formattedValue = cleanedValue.replace(/(\d{4})/g, '$1 ').trim();
        setCardData(prev => ({ ...prev, [name]: formattedValue.slice(0, 19) }));
    } else if (name === 'expiry') {
        const cleanedValue = value.replace(/\D/g, '');
        let formattedValue = cleanedValue;
        if (cleanedValue.length > 2) {
            formattedValue = `${cleanedValue.slice(0, 2)}/${cleanedValue.slice(2, 4)}`;
        }
        setCardData(prev => ({ ...prev, [name]: formattedValue }));
    } else if (name === 'cvc') {
        setCardData(prev => ({ ...prev, [name]: value.replace(/\D/g, '').slice(0, 3) }));
    } else {
        setCardData(prev => ({ ...prev, [name]: value }));
    }
  };

  return (
    <div className="space-y-6">
      <div 
        className="w-full h-48 rounded-xl bg-gradient-to-br from-primary to-accent text-primary-foreground p-4 flex flex-col justify-between transition-transform duration-500"
        style={{ transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)', transformStyle: 'preserve-3d' }}
      >
        <div style={{ transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)' }}>
          <div className="flex justify-between">
            <span>Credit Card</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
          </div>
          <div className="text-xl font-mono tracking-widest text-center">
            {cardData.number || '#### #### #### ####'}
          </div>
          <div className="flex justify-between text-sm">
            <div>
              <p className="text-xs">Card Holder</p>
              <p>{cardData.name || 'Your Name'}</p>
            </div>
            <div>
              <p className="text-xs">Expires</p>
              <p>{cardData.expiry || 'MM/YY'}</p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 left-0 w-full h-full p-4" style={{ transform: 'rotateY(180deg)', backfaceVisibility: 'hidden' }}>
            <div className="bg-black h-10 mt-6 -mx-4"></div>
            <div className="text-right mt-4">
                <p className="text-xs">CVC</p>
                <div className="bg-white text-black w-20 h-8 ml-auto rounded-md flex items-center justify-center font-mono">
                    {cardData.cvc}
                </div>
            </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="grid gap-2">
          <Label htmlFor="name">Cardholder Name</Label>
          <Input id="name" name="name" placeholder="John Doe" value={cardData.name} onChange={handleInputChange} onFocus={() => setIsFlipped(false)} />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="number">Card Number</Label>
          <Input id="number" name="number" placeholder="0000 0000 0000 0000" value={cardData.number} onChange={handleInputChange} onFocus={() => setIsFlipped(false)} />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="grid gap-2">
            <Label htmlFor="expiry">Expiry Date</Label>
            <Input id="expiry" name="expiry" placeholder="MM/YY" value={cardData.expiry} onChange={handleInputChange} onFocus={() => setIsFlipped(false)} />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="cvc">CVC</Label>
            <Input id="cvc" name="cvc" placeholder="123" value={cardData.cvc} onChange={handleInputChange} onFocus={() => setIsFlipped(true)} onBlur={() => setIsFlipped(false)} />
          </div>
        </div>
      </div>
      <Button onClick={onSubmit} className="w-full" variant="gradient">
        Pay with Card
      </Button>
    </div>
  );
}
