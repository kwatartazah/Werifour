
'use client';

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { paymentHistory } from '@/lib/data';
import { cn } from '@/lib/utils';
import { ScrollArea } from '../ui/scroll-area';

export function PaymentHistory() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Payment History</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[300px]">
            <Table>
            <TableHeader>
                <TableRow>
                <TableHead className="px-2">Date</TableHead>
                <TableHead className="px-2">Amount</TableHead>
                <TableHead className="px-2">Type</TableHead>
                <TableHead className="text-right px-2">Status</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {paymentHistory.map((payment) => (
                <TableRow key={payment.id}>
                    <TableCell className="px-2">{payment.date}</TableCell>
                    <TableCell className="px-2">${payment.amount}</TableCell>
                    <TableCell className="px-2">{payment.type}</TableCell>
                    <TableCell className="text-right px-2">
                    <Badge
                        className={cn({
                        'bg-green-500/20 text-green-700 border-green-500/30': payment.status === 'Paid',
                        'bg-yellow-500/20 text-yellow-700 border-yellow-500/30': payment.status === 'Pending',
                        'bg-red-500/20 text-red-700 border-red-500/30': payment.status === 'Failed',
                        })}
                    >
                        {payment.status}
                    </Badge>
                    </TableCell>
                </TableRow>
                ))}
            </TableBody>
            </Table>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
