
'use client';

import React from 'react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ArrowRight } from 'lucide-react';

type TaskCardProps = {
  description: string;
  link: string;
};

export function TaskCard({ description, link }: TaskCardProps) {
  return (
    <Card>
      <CardContent className="p-4">
        <Textarea
          readOnly
          value={description}
          className="resize-none border-0 bg-transparent text-sm text-card-foreground focus:ring-0 focus-visible:ring-0"
        />
      </CardContent>
      <CardFooter className="flex justify-end p-4 pt-0">
        <Button asChild variant="outline" size="sm">
          <a href={link} target="_blank" rel="noopener noreferrer">
            Go to link <ArrowRight className="ml-2 h-4 w-4" />
          </a>
        </Button>
      </CardFooter>
    </Card>
  );
}
