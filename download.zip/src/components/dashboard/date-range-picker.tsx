
'use client';

import React, { useState, useEffect } from 'react';
import { format, addDays, subDays, isValid, parse, isAfter } from 'date-fns';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';
import { DateRange } from 'react-day-picker';

import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';
import { Input } from '@/components/ui/input';
import { Label } from '../ui/label';

interface DateRangePickerProps extends React.HTMLAttributes<HTMLDivElement> {
  onDateChange?: (date: DateRange | undefined) => void;
}

export function DateRangePicker({ className, onDateChange }: DateRangePickerProps) {
  const [date, setDate] = useState<DateRange | undefined>({
    from: subDays(new Date(), 7),
    to: new Date(),
  });
  const [fromValue, setFromValue] = useState<string>(format(date?.from || new Date(), 'dd/MM/yy'));
  const [toValue, setToValue] = useState<string>(format(date?.to || new Date(), 'dd/MM/yy'));


  const { toast } = useToast();
  const isMobile = useIsMobile();

  useEffect(() => {
    if (date?.from) {
      setFromValue(format(date.from, 'dd/MM/yy'));
    }
    if (date?.to) {
      setToValue(format(date.to, 'dd/MM/yy'));
    }
    if (onDateChange) {
      onDateChange(date);
    }
  }, [date, onDateChange]);

  const handleDateSelect = (selectedDate: DateRange | undefined) => {
     if (selectedDate?.from && selectedDate?.to && isAfter(new Date(selectedDate.from), new Date(selectedDate.to))) {
        toast({
            variant: 'destructive',
            title: 'Invalid Date Range',
            description: 'The start date cannot be after the end date.',
        });
        return;
    }
    setDate(selectedDate);
  }
  
  const shiftDays = (days: number) => {
    const newFrom = date?.from ? addDays(date.from, days) : new Date();
    const newTo = date?.to ? addDays(date.to, days) : addDays(new Date(), 7);
    handleDateSelect({ from: newFrom, to: newTo });
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>, field: 'from' | 'to') => {
    const value = e.target.value;
    if (field === 'from') {
      setFromValue(value);
    } else {
      setToValue(value);
    }

    if (value.length >= 8) {
      const parsedDate = parse(value, 'dd/MM/yy', new Date());
      if (isValid(parsedDate)) {
        const newDate: DateRange = { from: date?.from, to: date?.to };
        if (field === 'from') {
          newDate.from = parsedDate;
        } else {
          newDate.to = parsedDate;
        }
        handleDateSelect(newDate);
      }
    }
  };


  return (
    <div className={cn('grid gap-2', className)}>
       <Popover>
        <PopoverTrigger asChild>
            <div className="flex items-center justify-start flex-wrap gap-1">
                <Button variant="outline" size="icon" className="h-8 w-8" onClick={(e) => { e.stopPropagation(); shiftDays(-1); }}>
                    <ChevronLeft className="h-4 w-4" />
                </Button>
                <div className="flex items-center gap-2">
                    <Input
                        type="text"
                        value={fromValue}
                        onChange={(e) => handleInputChange(e, 'from')}
                        className="w-[100px] h-8 text-center"
                        placeholder="dd/mm/yy"
                    />
                    <Label>to</Label>
                    <Input
                        type="text"
                        value={toValue}
                        onChange={(e) => handleInputChange(e, 'to')}
                        className="w-[100px] h-8 text-center"
                        placeholder="dd/mm/yy"
                    />
                </div>
                <Button variant="outline" size="icon" className="h-8 w-8" onClick={(e) => { e.stopPropagation(); shiftDays(1); }}>
                    <ChevronRight className="h-4 w-4" />
                </Button>
                <Button variant={'outline'} size="icon" className="h-8 w-8">
                    <CalendarIcon className="h-4 w-4" />
                </Button>
            </div>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start" alignOffset={-100}>
          <Calendar
            initialFocus
            mode="range"
            defaultMonth={date?.from}
            selected={date}
            onSelect={handleDateSelect}
            numberOfMonths={isMobile ? 1 : 2}
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}
