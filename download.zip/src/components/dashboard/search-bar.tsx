
'use client'

import { Search } from 'lucide-react'
import { Input } from '@/components/ui/input'

interface SearchBarProps extends React.InputHTMLAttributes<HTMLInputElement> {
  placeholder: string;
}

export function SearchBar({ placeholder, ...props }: SearchBarProps) {
  return (
    <div className="relative w-full max-w-md">
      <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
      <Input
        type="search"
        placeholder={placeholder}
        className="pr-10"
        {...props}
      />
    </div>
  )
}
