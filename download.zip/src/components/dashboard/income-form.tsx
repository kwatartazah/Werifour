'use client'

import React, { useState } from 'react'
import { Heart } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useToast } from '@/hooks/use-toast'
import { useTranslation } from '@/hooks/use-translation'

const monthlyOptions = [10, 25, 50]

export function IncomeForm() {
  const [monthlyAmount, setMonthlyAmount] = useState(25)
  const [oneTimeAmount, setOneTimeAmount] = useState<number | string>(50)
  const { toast } = useToast()
  const { t } = useTranslation()

  const handleOneTimeAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    if (value === '' || (Number(value) > 0 && !isNaN(Number(value)))) {
      setOneTimeAmount(value)
    }
  }

  const handleSubmit = (type: 'monthly' | 'one-time') => {
    const amount = type === 'monthly' ? monthlyAmount : oneTimeAmount
    toast({
      title: t('incomeForm.toast.title'),
      description: t('incomeForm.toast.description', { type: t(`incomeForm.toast.${type}`), amount }),
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('incomeForm.title')}</CardTitle>
        <CardDescription>
          {t('incomeForm.description')}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="monthly" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="monthly">{t('incomeForm.tabs.monthly')}</TabsTrigger>
            <TabsTrigger value="one-time">{t('incomeForm.tabs.oneTime')}</TabsTrigger>
          </TabsList>
          <TabsContent value="monthly" className="mt-6">
            <div className="space-y-6">
              <p className="text-sm text-center text-muted-foreground">
                {t('incomeForm.monthly.prompt')}
              </p>
              <div className="grid grid-cols-3 gap-4">
                {monthlyOptions.map(amount => (
                  <Button
                    key={amount}
                    variant={monthlyAmount === amount ? 'gradient-active' : 'gradient'}
                    onClick={() => setMonthlyAmount(amount)}
                    className="h-20 flex-col"
                  >
                    <span className="text-2xl font-bold font-headline">
                      {amount}
                    </span>
                    <span className="text-xs">/{t('incomeForm.monthly.month')}</span>
                  </Button>
                ))}
              </div>
              <Button
                onClick={() => handleSubmit('monthly')}
                className="w-full"
                variant="gradient"
              >
                <Heart className="mr-2 h-4 w-4" /> {t('incomeForm.monthly.subscribeButton', { amount: monthlyAmount })}
              </Button>
            </div>
          </TabsContent>
          <TabsContent value="one-time" className="mt-6">
            <div className="space-y-6">
              <div className="grid gap-2">
                <Label htmlFor="one-time-amount">{t('incomeForm.oneTime.customAmount')}</Label>
                <div className="relative">
                  <Input
                    id="one-time-amount"
                    type="number"
                    placeholder="50"
                    value={oneTimeAmount}
                    onChange={handleOneTimeAmountChange}
                    className="pl-7 text-lg font-bold font-headline"
                  />
                </div>
              </div>
              <Button
                onClick={() => handleSubmit('one-time')}
                className="w-full"
                variant="gradient"
              >
                <Heart className="mr-2 h-4 w-4" /> {t('incomeForm.oneTime.requestButton', { amount: oneTimeAmount || 0 })}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
