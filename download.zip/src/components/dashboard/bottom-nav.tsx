
'use client'

import Link from 'next/link'
import { Home, Users, Heart, HandHeart, UserCircle } from 'lucide-react'
import { usePathname } from 'next/navigation'
import { useTranslation } from '@/hooks/use-translation'

export function BottomNav() {
  const pathname = usePathname();
  const { t } = useTranslation();
  
  const navItems = [
    { href: '/', icon: Home, label: t('nav.home') },
    { href: '/services', icon: HandHeart, label: t('nav.services') },
    { href: '/members', icon: Users, label: t('nav.members') },
    { href: '/actions', icon: Heart, label: t('nav.actions') },
    { href: '/account', icon: UserCircle, label: t('nav.account') },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 border-t bg-card">
      <div className="mx-auto flex h-16 max-w-md items-center justify-around px-4">
        {navItems.map((item, index) => (
          <Link
            key={index}
            href={item.href}
            className={`flex flex-col items-center justify-center text-sm ${pathname === item.href ? 'text-primary' : 'text-foreground'} hover:text-primary`}
          >
            <item.icon className="h-6 w-6" />
            <span className="text-sm">{item.label}</span>
          </Link>
        ))}
      </div>
    </nav>
  )
}
