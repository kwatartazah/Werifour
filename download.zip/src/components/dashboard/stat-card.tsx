
'use client';

import React, { useState } from 'react';
import * as LucideIcons from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useTranslation } from '@/hooks/use-translation'
import { formatNumber, cn } from '@/lib/utils';

type StatCardProps = {
  title: string
  value: string | number
  change: string
  icon: keyof typeof LucideIcons
}

export function StatCard({ title, value, change, icon }: StatCardProps) {
  const { t } = useTranslation()
  const [showFullNumber, setShowFullNumber] = useState(false);
  const IconComponent = LucideIcons[icon] as React.FC<LucideIcons.LucideProps>
  const isPositive = change.startsWith('+')

  const description =
    title === t('stats.mytotalshare')
      ? t('statCard.description.myTotalShare', {change})
      : t('statCard.description.lastMonth', {change})

  const formattedValue = typeof value === 'number' ? formatNumber(value) : value;
  const fullValue = typeof value === 'number' ? value.toLocaleString() : value;

  const handleMouseEnter = () => {
    if (typeof value === 'number') {
      setShowFullNumber(true);
    }
  };

  const handleMouseLeave = () => {
    if (typeof value === 'number') {
      setShowFullNumber(false);
    }
  };

  return (
    <Card onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {IconComponent && (
          <IconComponent className="h-4 w-4 text-muted-foreground" />
        )}
      </CardHeader>
      <CardContent>
        <div 
          className={cn(
            "text-2xl font-bold font-headline",
            showFullNumber && "text-base"
          )}
        >
            {showFullNumber ? fullValue : formattedValue}
        </div>
        <p
          className={`text-xs ${
            isPositive || title === t('stats.mytotalshare')
              ? 'text-accent'
              : 'text-destructive'
          }`}
        >
          {description}
        </p>
      </CardContent>
    </Card>
  )
}

    