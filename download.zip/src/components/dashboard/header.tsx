
'use client';

import { useTranslation } from "@/hooks/use-translation";
import { useTheme } from "@/hooks/use-theme";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Sun, Moon } from "lucide-react";


export function DashboardHeader() {
  const { t } = useTranslation();
  const { theme, setTheme } = useTheme();

  return (
    <header className="flex h-16 items-center justify-between px-4 sm:px-6">
      <a
        href="#"
        className="flex items-center gap-2 text-lg font-semibold text-foreground"
      >
        <span
          className="font-headline"
          style={{
            color: '#6e0f2d',
            fontFamily: '"Times New Roman", Times, serif',
            fontWeight: 'bold',
            fontSize: '1.75rem',
          }}
        >
          {t('header.title')}
        </span>
      </a>

       <div className="flex items-center gap-2">
        {theme === 'pink' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        <Switch
          id="theme-switch"
          checked={theme === 'pink'}
          onCheckedChange={(checked) => setTheme(checked ? 'pink' : 'light')}
        />
        <Label htmlFor="theme-switch" className="sr-only">Toggle theme</Label>
      </div>
    </header>
  )
}
