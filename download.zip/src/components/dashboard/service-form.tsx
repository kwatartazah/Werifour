
'use client'

import React, { useState } from 'react'
import { Heart } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { AiSuggestion } from './ai-suggestion'
import { useToast } from '@/hooks/use-toast'

const monthlyOptions = [10, 25, 50]

export function ServiceForm() {
  const [monthlyAmount, setMonthlyAmount] = useState(25)
  const [oneTimeAmount, setOneTimeAmount] = useState<number | string>(50)
  const { toast } = useToast()

  const handleOneTimeAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    if (value === '' || (Number(value) > 0 && !isNaN(Number(value)))) {
      setOneTimeAmount(value)
    }
  }

  const handleSuggestionSelect = (amount: number) => {
    setOneTimeAmount(amount)
  }

  const handleSubmit = (type: 'monthly' | 'one-time') => {
    const amount = type === 'monthly' ? monthlyAmount : oneTimeAmount
    toast({
      title: 'Service Request Submitted!',
      description: `Thank you for your ${type} service request of ${amount}.`,
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Request a Service</CardTitle>
        <CardDescription>
          Choose a monthly subscription or make a one-time service request.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="monthly" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="monthly">Monthly</TabsTrigger>
            <TabsTrigger value="one-time">One-Time</TabsTrigger>
          </TabsList>
          <TabsContent value="monthly" className="mt-6">
            <div className="space-y-6">
              <p className="text-sm text-center text-muted-foreground">
                Select a monthly tier for ongoing service.
              </p>
              <div className="grid grid-cols-3 gap-4">
                {monthlyOptions.map(amount => (
                  <Button
                    key={amount}
                    variant={monthlyAmount === amount ? 'gradient-active' : 'gradient'}
                    onClick={() => setMonthlyAmount(amount)}
                    className="h-20 flex-col"
                  >
                    <span className="text-2xl font-bold font-headline">
                      {amount}
                    </span>
                    <span className="text-xs">/month</span>
                  </Button>
                ))}
              </div>
              <Button
                onClick={() => handleSubmit('monthly')}
                className="w-full"
                variant="gradient"
              >
                <Heart className="mr-2 h-4 w-4" /> Subscribe for 
                {monthlyAmount}/month
              </Button>
            </div>
          </TabsContent>
          <TabsContent value="one-time" className="mt-6">
            <div className="space-y-6">
              <div className="grid gap-2">
                <Label htmlFor="one-time-amount">Custom Amount</Label>
                <div className="relative">
                  <Input
                    id="one-time-amount"
                    type="number"
                    placeholder="50"
                    value={oneTimeAmount}
                    onChange={handleOneTimeAmountChange}
                    className="pl-7 text-lg font-bold font-headline"
                  />
                </div>
              </div>
              <AiSuggestion onSuggestionSelect={handleSuggestionSelect} />
              <Button
                onClick={() => handleSubmit('one-time')}
                className="w-full"
                variant="gradient"
              >
                <Heart className="mr-2 h-4 w-4" /> Request Service for {oneTimeAmount || 0}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
