
'use client';

import React from 'react';
import { ThumbsUpIcon, ThumbsDownIcon } from '@/components/icons';

type ActionCardProps = {
  description: string;
};

export function ActionCard({ description }: ActionCardProps) {
  return (
    <div className="rounded-lg border bg-card text-card-foreground shadow-sm p-4">
      <div className="h-40 bg-blue-500/20 rounded-md flex items-center justify-center mb-4">
        <p className="text-primary font-semibold">{description}</p>
      </div>
      <div className="flex justify-end space-x-4">
        <button className="focus:outline-none">
          <ThumbsUpIcon className="h-8 w-8 text-green-500" />
        </button>
        <button className="focus:outline-none">
          <ThumbsDownIcon className="h-8 w-8 text-red-500" />
        </button>
      </div>
    </div>
  );
}
