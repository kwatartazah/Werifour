
'use client';

import { DashboardHeader } from '@/components/dashboard/header';
import { BottomNav } from '@/components/dashboard/bottom-nav';
import { SearchBar } from '@/components/dashboard/search-bar';

export default function InvestmentsPage() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <DashboardHeader />
      <main className="flex flex-1 flex-col items-center gap-6 bg-background p-4 sm:p-6 md:p-8 mb-16">
        <SearchBar placeholder="Search for an investment by ID or name..." />
        <div className="text-center">
          <h1 className="text-2xl font-bold">Investments Page</h1>
          <p className="text-muted-foreground">Investment data will be displayed here.</p>
        </div>
      </main>
      <BottomNav />
    </div>
  );
}
