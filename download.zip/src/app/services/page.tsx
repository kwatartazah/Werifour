
'use client';

import React, { useState, useCallback } from 'react';
import { useSwipeable } from 'react-swipeable';

import { DashboardHeader } from '@/components/dashboard/header';
import { BottomNav } from '@/components/dashboard/bottom-nav';
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from '@/components/ui/table';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { AnalyticsChart } from '@/components/dashboard/analytics-chart';
import { PieChartComponent } from '@/components/dashboard/pie-chart';
import { DateRangePicker } from '@/components/dashboard/date-range-picker';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useTranslation } from '@/hooks/use-translation';
import { DateRange } from 'react-day-picker';

const initialServices = [
    { name: 'Economic investment', totalSpend: 120500, periodSpend: 5500 },
    { name: 'Education', totalSpend: 85300, periodSpend: 4200 },
    { name: 'Health', totalSpend: 150000, periodSpend: 7800 },
    { name: 'Infrastructure', totalSpend: 210000, periodSpend: 10100 },
    { name: 'Environment', totalSpend: 60000, periodSpend: 2500 },
    { name: 'Nutrition', totalSpend: 75000, periodSpend: 3800 },
    { name: 'SLM/A', totalSpend: 45000, periodSpend: 1900 },
    { name: 'Water', totalSpend: 95000, periodSpend: 4600 },
];

const TABS = ['services', 'analytics', 'breakdown'];

export default function ServicesPage() {
  const [activeTab, setActiveTab] = useState(TABS[0]);
  const { t } = useTranslation();
  const [servicesData, setServicesData] = useState(initialServices);

  const handleDateChange = useCallback((dateRange: DateRange | undefined) => {
    if (!dateRange) return;

    // Simulate fetching new data for the selected period
    setServicesData(prevServices => prevServices.map(service => ({
      ...service,
      periodSpend: Math.floor(Math.random() * (service.totalSpend / 10)) + 1000,
    })));
  }, []);


  const handleSwipe = (direction: 'left' | 'right') => {
    const currentIndex = TABS.indexOf(activeTab);
    if (direction === 'left') {
      const nextIndex = (currentIndex + 1) % TABS.length;
      setActiveTab(TABS[nextIndex]);
    } else {
      const nextIndex = (currentIndex - 1 + TABS.length) % TABS.length;
      setActiveTab(TABS[nextIndex]);
    }
  };

  const swipeHandlers = useSwipeable({
    onSwipedLeft: () => handleSwipe('left'),
    onSwipedRight: () => handleSwipe('right'),
    preventScrollOnSwipe: true,
    trackMouse: true,
  });

  return (
    <div className="flex min-h-screen w-full flex-col">
      <DashboardHeader />
      <main className="flex flex-1 flex-col items-center gap-6 bg-background p-4 sm:p-6 md:p-8 mb-16">
        <div className="w-full max-w-4xl space-y-6">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="services">{t('services.tabs.services')}</TabsTrigger>
                    <TabsTrigger value="analytics">{t('services.tabs.analytics')}</TabsTrigger>
                    <TabsTrigger value="breakdown">{t('services.tabs.breakdown')}</TabsTrigger>
                </TabsList>
                 <div {...swipeHandlers}>
                    <TabsContent value="services" className="mt-6">
                        <Card>
                        <Table>
                            <TableHeader>
                            <TableRow className="bg-primary/20 hover:bg-primary/30">
                                <TableHead className="text-primary font-bold px-2">Service</TableHead>
                                <TableHead className="text-primary font-bold text-right px-2">Total Spend</TableHead>
                            </TableRow>
                            </TableHeader>
                            <TableBody>
                            {initialServices.map((service) => (
                                <TableRow key={service.name}>
                                <TableCell className="font-medium px-2">{service.name}</TableCell>
                                <TableCell className="text-right px-2">{service.totalSpend.toLocaleString()}</TableCell>
                                </TableRow>
                            ))}
                            </TableBody>
                        </Table>
                        </Card>
                    </TabsContent>
                    <TabsContent value="analytics" className="mt-6">
                        <AnalyticsChart title="Services Analytics" description="Aggregated services trends over time." dataKey="services" />
                    </TabsContent>
                    <TabsContent value="breakdown" className="mt-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <Card>
                              <CardHeader>
                                <CardTitle>Total Spend by Service</CardTitle>
                                <CardDescription>Breakdown of total spending across all services.</CardDescription>
                              </CardHeader>
                              <CardContent className="p-4">
                                <PieChartComponent 
                                    data={initialServices} 
                                    dataKey="totalSpend"
                                    nameKey="name"
                                    hasCard={false}
                                />
                              </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="flex flex-col items-start gap-4">
                                    <div className="flex flex-col gap-y-1.5">
                                        <CardTitle>Period Spend by Service</CardTitle>
                                        <CardDescription>Breakdown of spending for the selected period.</CardDescription>
                                    </div>
                                    <div className="w-full">
                                      <DateRangePicker onDateChange={handleDateChange}/>
                                    </div>
                                </CardHeader>
                                <CardContent className="p-4">
                                    <PieChartComponent 
                                        data={servicesData} 
                                        dataKey="periodSpend"
                                        nameKey="name"
                                        hasCard={false}
                                    />
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>
                </div>
            </Tabs>
        </div>
      </main>
      <BottomNav />
    </div>
  );
}
