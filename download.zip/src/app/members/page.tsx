
'use client';

import React, { useState, useCallback } from 'react';
import Image from 'next/image';
import { ArrowUpDown } from 'lucide-react';
import { useSwipeable } from 'react-swipeable';

import { Button } from '@/components/ui/button';
import { DashboardHeader } from '@/components/dashboard/header';
import { BottomNav } from '@/components/dashboard/bottom-nav';
import { SearchBar } from '@/components/dashboard/search-bar';
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { countries } from '@/lib/countries';
import { PieChartComponent } from '@/components/dashboard/pie-chart';
import { useTranslation } from '@/hooks/use-translation';
import { formatNumber } from '@/lib/utils';
import { DateRangePicker } from '@/components/dashboard/date-range-picker';
import { DateRange } from 'react-day-picker';
import { ScrollArea } from '@/components/ui/scroll-area';

const totalMembers = 10254;
const memberDistributionConfig: { [key: string]: number } = {
  GB: 0.15, // 15%
  FR: 0.10, // 10%
  IL: 0.05, // 5%
  US: 0.40, // 40%
  DE: 0.20, // 20%
  SE: 0.10, // 10%
};

const memberDistribution = Object.entries(memberDistributionConfig).reduce(
  (acc, [code, percentage]) => {
    acc[code] = Math.floor(totalMembers * percentage);
    return acc;
  },
  {} as { [key: string]: number }
);

const totalInvestment = 42540000577;
const totalInvestmentByCountry: { [key: string]: number } = {
  US: totalInvestment * 0.40,
  DE: totalInvestment * 0.20,
  GB: totalInvestment * 0.15,
  FR: totalInvestment * 0.10,
  SE: totalInvestment * 0.10,
  IL: totalInvestment * 0.05,
};

export const members: {
    id: string;
    username: string;
    firstName: string;
    lastName: string;
    totalInvestment: string;
    active: boolean;
    email: string;
    phoneNumber: string;
    password: string;
    country: string;
    gender: 'male' | 'female';
}[] = [
    { id: 'USR-001', username: 'Khadija', firstName: 'Khadija', lastName: 'Ali', totalInvestment: '12,250', active: true, email: 'khadija@example.com', phoneNumber: '+1111111111', password: 'Password1!', country: 'US', gender: 'female' },
    { id: 'USR-002', username: 'Ahmed', firstName: 'Ahmed', lastName: 'Khan', totalInvestment: '9,800', active: false, email: 'ahmed@example.com', phoneNumber: '+2222222222', password: 'Password1!', country: 'GB', gender: 'male' },
    { id: 'USR-003', username: 'Fatima', firstName: 'Fatima', lastName: 'Zahra', totalInvestment: '25,000', active: true, email: 'fatima@example.com', phoneNumber: '+3333333333', password: 'Password1!', country: 'FR', gender: 'female' },
    { id: 'USR-004', username: 'Mustafa', firstName: 'Mustafa', lastName: 'Hassan', totalInvestment: '7,200', active: false, email: 'mustafa@example.com', phoneNumber: '+4444444444', password: 'Password1!', country: 'DE', gender: 'male' },
    { id: 'USR-005', username: 'Aisha', firstName: 'Aisha', lastName: 'Abbas', totalInvestment: '31,000', active: true, email: 'aisha@example.com', phoneNumber: '+5555555555', password: 'Password1!', country: 'SE', gender: 'female' },
    { id: 'USR-006', username: 'Ibrahim', firstName: 'Ibrahim', lastName: 'Farooq', totalInvestment: '4,500', active: true, email: 'ibrahim@example.com', phoneNumber: '+6666666666', password: 'Password1!', country: 'IL', gender: 'male' },
    { id: 'USR-007', username: 'Zainab', firstName: 'Zainab', lastName: 'Bibi', totalInvestment: '18,000', active: false, email: 'zainab@example.com', phoneNumber: '+7777777777', password: 'Password1!', country: 'US', gender: 'female' },
    { id: 'USR-008', username: 'Omar', firstName: 'Omar', lastName: 'Syed', totalInvestment: '6,000', active: false, email: 'omar@example.com', phoneNumber: '+8888888888', password: 'Password1!', country: 'GB', gender: 'male' },
    { id: 'USR-009', username: 'Layla', firstName: 'Layla', lastName: 'Jamal', totalInvestment: '22,000', active: true, email: 'layla@example.com', phoneNumber: '+9999999999', password: 'Password1!', country: 'FR', gender: 'female' },
    { id: 'USR-010', username: 'Yusuf', firstName: 'Yusuf', lastName: 'Malik', totalInvestment: '11,000', active: false, email: 'yusuf@example.com', phoneNumber: '+1010101010', password: 'Password1!', country: 'DE', gender: 'male' },
    { id: 'USR-011', username: 'izzoaldo', firstName: 'Izzo', lastName: 'Aldo', email: 'izzoaldo@gmail.com', phoneNumber: '+1234567890', password: 'Izzoaldo1!', totalInvestment: '50,000', active: true, country: 'US', gender: 'male' },
];

const countryData = countries
  .map(country => {
    const members = memberDistribution[country.code] || 0;
    const investment = totalInvestmentByCountry[country.code] || 0;
    const subscribedMembers = Math.floor(members * 0.9); // 90% are subscribed
    
    return {
      ...country,
      members,
      investment,
      periodInvestment: investment,
      subscribedMembers,
      periodSubscribedMembers: subscribedMembers,
    };
  })
  .filter(country => country.members > 0)
  .sort((a, b) => b.investment - a.investment);

const TABS = ['members', 'countries', 'breakdown'];

export default function MembersPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState(TABS[0]);
  const { t } = useTranslation();
  const [countryPeriodData, setCountryPeriodData] = useState(countryData);
  const [subscribedMembersPeriodData, setSubscribedMembersPeriodData] = useState(countryData);
  
  const filteredMembers = members.filter(member =>
    member.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    `${member.firstName} ${member.lastName}`.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleInvestmentDateChange = useCallback((dateRange: DateRange | undefined) => {
    if (!dateRange) return;

    // Simulate fetching new data for the selected period
    setCountryPeriodData(prevData => prevData.map(country => ({
      ...country,
      periodInvestment: Math.floor(Math.random() * (country.investment / 10)) + 1000,
    })));
  }, []);

  const handleSubscribedMembersDateChange = useCallback((dateRange: DateRange | undefined) => {
    if (!dateRange) return;

    // Simulate fetching new data for the selected period
    setSubscribedMembersPeriodData(prevData => prevData.map(country => ({
      ...country,
      periodSubscribedMembers: Math.floor(Math.random() * (country.subscribedMembers / 2)) + 100,
    })));
  }, []);

  const swipeHandlers = useSwipeable({
    onSwipedLeft: () => {
      const currentIndex = TABS.indexOf(activeTab);
      const nextIndex = (currentIndex + 1) % TABS.length;
      setActiveTab(TABS[nextIndex]);
    },
    onSwipedRight: () => {
      const currentIndex = TABS.indexOf(activeTab);
      const nextIndex = (currentIndex - 1 + TABS.length) % TABS.length;
      setActiveTab(TABS[nextIndex]);
    },
    preventScrollOnSwipe: true,
    trackMouse: true,
  });

  return (
    <div className="flex min-h-screen w-full flex-col">
      <DashboardHeader />
      <main className="flex flex-1 flex-col items-center gap-6 bg-background p-4 sm:p-6 md:p-8 mb-16">
        <SearchBar 
            placeholder="Search for a member by ID or name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
        />
        <div className="w-full max-w-6xl">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="members">{t('members.tabs.members')}</TabsTrigger>
              <TabsTrigger value="countries">{t('members.tabs.countryList')}</TabsTrigger>
              <TabsTrigger value="breakdown">{t('members.tabs.breakdown')}</TabsTrigger>
            </TabsList>
            <div {...swipeHandlers} className="mt-6">
              <TabsContent value="members" className="space-y-6">
                <Card>
                  <ScrollArea className="h-[400px]">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-primary/20 hover:bg-primary/30">
                          <TableHead className="text-primary font-bold px-2">ID</TableHead>
                          <TableHead className="text-primary font-bold px-2">Username</TableHead>
                          <TableHead className="text-primary font-bold text-right px-2">Total investment</TableHead>
                          <TableHead className="text-primary font-bold px-2">subscribed</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredMembers.map(member => (
                          <TableRow key={member.id}>
                            <TableCell className="px-2">{member.id}</TableCell>
                            <TableCell className="px-2">{member.username}</TableCell>
                            <TableCell className="text-right px-2">{member.totalInvestment}</TableCell>
                            <TableCell className="px-2">{member.active ? 'Yes' : 'No'}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </Card>
              </TabsContent>
              <TabsContent value="countries" className="space-y-6">
                <Card>
                  <ScrollArea className="h-[400px]">
                    <Table>
                    <TableHeader>
                        <TableRow className="bg-primary/20 hover:bg-primary/30">
                        <TableHead className="text-primary font-bold px-2">
                            <Button variant="ghost" className="text-primary font-bold p-0 hover:bg-transparent">
                            {t('members.tabs.countryList')}
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                            </Button>
                        </TableHead>
                        <TableHead className="text-primary font-bold px-2">Number of members</TableHead>
                        <TableHead className="text-primary font-bold text-right px-2">Total investment</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {countryData.filter(c => c.members > 0).map(country => (
                        <TableRow key={country.code}>
                            <TableCell className="flex items-center gap-2 px-2">
                            <Image
                                src={`https://flagcdn.com/w20/${country.code.toLowerCase()}.png`}
                                alt={`${country.name} flag`}
                                width={20}
                                height={15}
                                className="rounded-sm"
                            />
                            {country.name}
                            </TableCell>
                            <TableCell className="px-2">{country.members.toLocaleString()}</TableCell>
                            <TableCell className="text-right px-2">{formatNumber(country.investment)}</TableCell>
                        </TableRow>
                        ))}
                    </TableBody>
                    </Table>
                  </ScrollArea>
                </Card>
              </TabsContent>
              <TabsContent value="breakdown" className="space-y-6">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Total Investment Distribution</CardTitle>
                        <CardDescription>Breakdown of total investment by country.</CardDescription>
                      </CardHeader>
                      <CardContent className="p-4">
                        <PieChartComponent 
                            data={countryData} 
                            dataKey="investment"
                            nameKey="name"
                            hasCard={false}
                        />
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader>
                        <CardTitle>Member Distribution</CardTitle>
                        <CardDescription>Breakdown of members by country.</CardDescription>
                      </CardHeader>
                      <CardContent className="p-4">
                        <PieChartComponent 
                            data={countryData} 
                            dataKey="members"
                            nameKey="name"
                            hasCard={false}
                        />
                      </CardContent>
                    </Card>
                    <Card>
                        <CardHeader className="flex flex-col items-start gap-4">
                            <div className="flex flex-col gap-y-1.5">
                                <CardTitle>Period Investment by Country</CardTitle>
                                <CardDescription>Breakdown of investment for the selected period.</CardDescription>
                            </div>
                            <div className="w-full">
                              <DateRangePicker onDateChange={handleInvestmentDateChange}/>
                            </div>
                        </CardHeader>
                        <CardContent className="p-4">
                            <PieChartComponent 
                                data={countryPeriodData} 
                                dataKey="periodInvestment"
                                nameKey="name"
                                hasCard={false}
                            />
                        </CardContent>
                    </Card>
                     <Card>
                        <CardHeader className="flex flex-col items-start gap-4">
                            <div className="flex flex-col gap-y-1.5">
                                <CardTitle>Period Subscribed Member Distribution</CardTitle>
                                <CardDescription>Breakdown of subscribed members for the selected period.</CardDescription>
                            </div>
                            <div className="w-full">
                              <DateRangePicker onDateChange={handleSubscribedMembersDateChange}/>
                            </div>
                        </CardHeader>
                        <CardContent className="p-4">
                            <PieChartComponent 
                                data={subscribedMembersPeriodData} 
                                dataKey="periodSubscribedMembers"
                                nameKey="name"
                                hasCard={false}
                            />
                        </CardContent>
                    </Card>
                 </div>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </main>
      <BottomNav />
    </div>
  );
}

    

    

    
