
'use server'

import {
  suggestInvestment,
  type SuggestInvestmentInput,
} from '@/ai/flows/suggest-investment-amount'

export async function getInvestmentSuggestion(input: SuggestInvestmentInput) {
  try {
    const result = await suggestInvestment(input)
    if (!result.suggestedInvestment) {
      return { error: 'Could not generate a suggestion. Please try again.' }
    }
    return result
  } catch (error) {
    console.error('Error getting investment suggestion:', error)
    return {
      error: 'An unexpected error occurred while fetching your suggestion.',
    }
  }
}
