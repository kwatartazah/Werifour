
'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useForm, useFormContext } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Eye, EyeOff } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { useTranslation } from '@/hooks/use-translation';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { countries } from '@/lib/countries';
import { SupportDialog } from '@/components/auth/support-dialog';
import { members } from '@/app/members/page';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

const passwordSchema = z.string()
  .min(8, { message: "Password must be between 8 and 20 characters." })
  .max(20, { message: "Password must be between 8 and 20 characters." })
  .regex(/[A-Z]/, { message: "Password must contain at least one uppercase letter." })
  .regex(/[a-z]/, { message: "Password must contain at least one lowercase letter." })
  .regex(/[0-9]/, { message: "Password must contain at least one number." })
  .regex(/[^A-Za-z0-9]/, { message: "Password must contain at least one special character." });

const registerSchema = z.object({
  username: z.string()
    .min(4, { message: 'Username must be 4 to 20 characters and contain no spaces' })
    .max(20, { message: 'Username must be 4 to 20 characters and contain no spaces' })
    .refine(s => !s.includes(' '), { message: 'Username must not contain spaces' }),
  firstName: z.string().min(1, 'First name is required').regex(/^[a-zA-Z]+$/, 'First name can only contain letters'),
  lastName: z.string().min(1, 'Last name is required').regex(/^[a-zA-Z]+$/, 'Last name can only contain letters'),
  email: z.string().email('Invalid email address'),
  phoneNumber: z.string().min(1, 'Phone number is required'),
  country: z.string().min(1, 'Country is required'),
  gender: z.enum(['male', 'female'], { required_error: 'Please select a gender.' }),
  password: passwordSchema,
  confirmPassword: z.string()
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type RegisterFormValues = z.infer<typeof registerSchema>;

export default function RegisterPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { t } = useTranslation();

  const form = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: '',
      firstName: '',
      lastName: '',
      email: '',
      phoneNumber: '',
      country: '',
      password: '',
      confirmPassword: '',
    },
  });

  const onSubmit = (data: RegisterFormValues) => {
    const existingMember = members.find(member => member.username.toLowerCase() === data.username.toLowerCase() || member.email === data.email);
    if (existingMember) {
        toast({
            variant: 'destructive',
            title: 'Registration Failed',
            description: 'A member with this username or email already exists.',
        });
        return;
    }
    
    // Simulate saving the new user
    const newId = `USR-0${members.length + 11}`;
    members.push({
        id: newId,
        username: data.username,
        firstName: data.firstName,
        lastName: data.lastName,
        totalInvestment: '0',
        active: true,
        email: data.email,
        phoneNumber: data.phoneNumber,
        password: data.password,
        country: data.country,
        gender: data.gender,
    });

    toast({
      title: t('register.toast.title'),
      description: t('register.toast.description'),
    });
    router.push('/login');
  };

  return (
    <div className="flex min-h-screen w-full flex-col items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl">{t('register.title')}</CardTitle>
          <CardDescription>{t('register.description')}</CardDescription>
        </CardHeader>
        <CardContent>
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                        control={form.control}
                        name="username"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('register.username')}</FormLabel>
                                <FormControl>
                                    <Input placeholder={t('register.placeholders.username')} {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                     <FormField
                        control={form.control}
                        name="firstName"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('register.firstName')}</FormLabel>
                                <FormControl>
                                    <Input placeholder={t('register.placeholders.firstName')} {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                     <FormField
                        control={form.control}
                        name="lastName"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('register.lastName')}</FormLabel>
                                <FormControl>
                                    <Input placeholder={t('register.placeholders.lastName')} {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('myDetails.email')}</FormLabel>
                                <FormControl>
                                    <Input type="email" placeholder="m@example.com" {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                     <FormField
                        control={form.control}
                        name="phoneNumber"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('myDetails.phoneNumber')}</FormLabel>
                                <FormControl>
                                    <Input type="tel" placeholder="+1234567890" {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="country"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('myDetails.country')}</FormLabel>
                                 <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                        <SelectTrigger>
                                            <SelectValue placeholder={t('myDetails.countryPlaceholder')} />
                                        </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                        {countries.map(country => (
                                        <SelectItem key={country.code} value={country.code}>
                                            {country.name}
                                        </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                     <FormField
                        control={form.control}
                        name="gender"
                        render={({ field }) => (
                            <FormItem className="space-y-3">
                                <FormLabel>{t('register.gender.label')}</FormLabel>
                                <FormControl>
                                    <RadioGroup
                                    onValueChange={field.onChange}
                                    defaultValue={field.value}
                                    className="flex items-center space-x-4"
                                    >
                                    <FormItem className="flex items-center space-x-2 space-y-0">
                                        <FormControl>
                                        <RadioGroupItem value="male" />
                                        </FormControl>
                                        <FormLabel className="font-normal">
                                            {t('register.gender.male')}
                                        </FormLabel>
                                    </FormItem>
                                    <FormItem className="flex items-center space-x-2 space-y-0">
                                        <FormControl>
                                        <RadioGroupItem value="female" />
                                        </FormControl>
                                        <FormLabel className="font-normal">
                                            {t('register.gender.female')}
                                        </FormLabel>
                                    </FormItem>
                                    </RadioGroup>
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <PasswordField name="password" label={t('myDetails.password')} />
                    <PasswordField name="confirmPassword" label={t('register.confirmPassword')} />
                   
                    <Button type="submit" className="w-full">
                        {t('register.button')}
                    </Button>
                </form>
            </Form>
        </CardContent>
         <CardFooter className="flex flex-col items-center gap-2 text-sm">
            <p>{t('register.hasAccount')} <Link href="/login" className="font-semibold text-primary hover:underline">{t('register.loginLink')}</Link></p>
            <SupportDialog />
        </CardFooter>
      </Card>
    </div>
  );
}

function PasswordField({ name, label }: { name: "password" | "confirmPassword", label: string }) {
    const { t } = useTranslation();
    const [showPassword, setShowPassword] = useState(false);
    const { control } = useFormContext<RegisterFormValues>();
    return (
        <FormField
            control={control}
            name={name}
            render={({ field }) => (
                <FormItem>
                <FormLabel>{label}</FormLabel>
                <FormControl>
                    <div className="relative">
                    <Input type={showPassword ? 'text' : 'password'} {...field} />
                    <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute inset-y-0 right-0 h-full px-3"
                        onClick={() => setShowPassword(!showPassword)}
                    >
                        {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </Button>
                    </div>
                </FormControl>
                 {name === 'password' && <FormDescription>{t('myDetails.validation.password.note')}</FormDescription>}
                <FormMessage />
                </FormItem>
            )}
        />
    )
}
