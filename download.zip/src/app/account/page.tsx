
'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm, FormProvider, useFormContext, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Eye, EyeOff, LogOut, LifeBuoy } from 'lucide-react';

import { DashboardHeader } from '@/components/dashboard/header';
import { BottomNav } from '@/components/dashboard/bottom-nav';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useTranslation } from '@/hooks/use-translation';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { countries } from '@/lib/countries';
import { FormControl, FormField, FormItem, FormMessage, FormDescription } from '@/components/ui/form';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription as DialogDescriptionComponent, DialogFooter, DialogClose, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';

const memberNameSchema = z.object({ memberName: z.string().min(1, 'Member name is required') });
const emailSchema = z.object({ email: z.string().email('Invalid email address') });
const phoneSchema = z.object({ phoneNumber: z.string().min(1, 'Phone number is required') });
const passwordSchema = z.object({
    password: z.string()
      .min(8, { message: "Password must be between 8 and 20 characters." })
      .max(20, { message: "Password must be between 8 and 20 characters." })
      .regex(/[A-Z]/, { message: "Password must contain at least one uppercase letter." })
      .regex(/[a-z]/, { message: "Password must contain at least one lowercase letter." })
      .regex(/[0-9]/, { message: "Password must contain at least one number." })
      .regex(/[^A-Za-z0-9]/, { message: "Password must contain at least one special character." })
});
const countrySchema = z.object({ country: z.string().min(1, 'Country is required') });

const supportSchema = z.object({
    name: z.string().min(1, 'Name is required'),
    email: z.string().email('Invalid email address'),
    message: z.string().min(1, 'Message is required'),
});


type UpdatableField = 'memberName' | 'email' | 'phoneNumber' | 'password' | 'country';

export default function MyDetailsPage() {
  const { t, language, setLanguage } = useTranslation();
  const { toast } = useToast();
  const router = useRouter();
  
  const [emailCode, setEmailCode] = useState('');
  const [phoneCode, setPhoneCode] = useState('');
  
  const [userData, setUserData] = useState({
    memberName: 'Khadija',
    email: 'khadija@example.com',
    phoneNumber: '+1234567890',
    password: 'Password123!',
    country: 'US',
  });

  const handleSendCode = (type: 'email' | 'phone') => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    toast({
      title: t('myDetails.sendCodeToast.title'),
      description: t('myDetails.sendCodeToast.descriptionWithCode', { type: t(`myDetails.sendCodeToast.${type}`), code: code }),
    });
  }

  const handleVerifyCode = (type: 'email' | 'phone') => {
    toast({
      title: t('myDetails.verifyCodeToast.title'),
      description: t('myDetails.verifyCodeToast.description', { type: t(`myDetails.sendCodeToast.${type}`) }),
    });
  }
  
  const handleUpdate = (field: UpdatableField, data: any) => {
    setUserData(prev => ({...prev, ...data}));
    toast({
        title: t('myDetails.updateDialog.toast.title'),
        description: t('myDetails.updateDialog.toast.description', { field: t(`myDetails.updateDialog.fields.${field}`) }),
    });
  }

  const handleLogout = () => {
    toast({
        title: t('myDetails.logoutToast.title'),
        description: t('myDetails.logoutToast.description'),
    });
    router.push('/login');
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <DashboardHeader />
      <main className="flex flex-1 flex-col items-center gap-6 bg-background p-4 sm:p-6 md:p-8 mb-16">
        <div className="w-full max-w-md space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>{t('myDetails.title')}</CardTitle>
                    <CardDescription>{t('myDetails.description')}</CardDescription>
                </CardHeader>
            </Card>

            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                        <Label>{t('myDetails.memberId')}</Label>
                        <p className="text-lg font-semibold">USR-001</p>
                    </div>
                </CardHeader>
            </Card>

            <UpdateCard
                title={t('myDetails.memberName')}
                field="memberName"
                value={userData.memberName}
                schema={memberNameSchema}
                onUpdate={handleUpdate}
            >
                <ControlledInput name="memberName" />
            </UpdateCard>
            
            <UpdateCard
                title={t('myDetails.email')}
                field="email"
                value={userData.email}
                schema={emailSchema}
                onUpdate={handleUpdate}
            >
                <div className="space-y-4">
                    <ControlledInput name="email" type="email" />
                    <Button type="button" variant="outline" size="sm" onClick={() => handleSendCode('email')} className="w-full">{t('myDetails.sendCode')}</Button>
                    <div className="flex items-center gap-2">
                        <Input type="text" placeholder={t('myDetails.confirmationCode')} value={emailCode} onChange={(e) => setEmailCode(e.target.value)} />
                        <Button type="button" size="sm" onClick={() => handleVerifyCode('email')} disabled={!emailCode}>{t('myDetails.verify')}</Button>
                    </div>
                </div>
            </UpdateCard>

            <UpdateCard
                title={t('myDetails.phoneNumber')}
                field="phoneNumber"
                value={userData.phoneNumber}
                schema={phoneSchema}
                onUpdate={handleUpdate}
            >
                <div className="space-y-4">
                    <ControlledInput name="phoneNumber" type="tel" />
                    <Button type="button" variant="outline" size="sm" onClick={() => handleSendCode('phone')} className="w-full">{t('myDetails.sendCode')}</Button>
                    <div className="flex items-center gap-2">
                        <Input type="text" placeholder={t('myDetails.confirmationCode')} value={phoneCode} onChange={(e) => setPhoneCode(e.target.value)} />
                        <Button type="button" size="sm" onClick={() => handleVerifyCode('phone')} disabled={!phoneCode}>{t('myDetails.verify')}</Button>
                    </div>
                </div>
            </UpdateCard>

            <UpdateCard
                title={t('myDetails.password')}
                field="password"
                value="••••••••"
                schema={passwordSchema}
                onUpdate={handleUpdate}
            >
                <PasswordInput name="password" />
            </UpdateCard>

            <UpdateCard
                title={t('myDetails.country')}
                field="country"
                value={countries.find(c => c.code === userData.country)?.name || userData.country}
                schema={countrySchema}
                onUpdate={handleUpdate}
            >
                <FormField
                    name="country"
                    render={({ field }) => (
                        <FormItem>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder={t('myDetails.countryPlaceholder')} />
                                    </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    {countries.map(country => (
                                    <SelectItem key={country.code} value={country.code}>
                                        {country.name}
                                    </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )}
                />
            </UpdateCard>

            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                        <Label>{t('accountMenu.language')}</Label>
                        <p className="text-lg font-semibold">
                            {language === 'en' ? t('accountMenu.languages.english') : t('accountMenu.languages.arabic')}
                        </p>
                    </div>
                    <Select value={language} onValueChange={(value) => setLanguage(value as 'en' | 'ar')}>
                        <SelectTrigger className="w-[120px]">
                            <SelectValue placeholder={t('accountMenu.language')} />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="en">{t('accountMenu.languages.english')}</SelectItem>
                            <SelectItem value="ar">{t('accountMenu.languages.arabic')}</SelectItem>
                        </SelectContent>
                    </Select>
                </CardHeader>
            </Card>

            <SupportCard />
            
            <Card>
                <CardHeader>
                    <Button variant="destructive" onClick={handleLogout} className="w-full">
                        <LogOut className="mr-2 h-4 w-4" />
                        {t('accountMenu.logout')}
                    </Button>
                </CardHeader>
            </Card>
        </div>
      </main>
      <BottomNav />
    </div>
  );
}

function PasswordInput({ name }: { name: string }) {
    const { t } = useTranslation();
    const [showPassword, setShowPassword] = useState(false);
    const { control } = useFormContext();
    return (
        <Controller
            name={name}
            control={control}
            render={({ field, fieldState }) => (
                <FormItem>
                    <div className="relative">
                        <FormControl>
                             <Input type={showPassword ? 'text' : 'password'} {...field} />
                        </FormControl>
                        <Button type="button" variant="ghost" size="icon" className="absolute inset-y-0 right-0 h-full px-3" onClick={() => setShowPassword(!showPassword)}>
                            {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                        </Button>
                    </div>
                    <FormDescription className="pt-2">{t('myDetails.validation.password.note')}</FormDescription>
                    {fieldState.error && <FormMessage>{fieldState.error.message}</FormMessage>}
                </FormItem>
            )}
        />
    )
}


interface UpdateCardProps {
    title: string;
    field: UpdatableField;
    value: string;
    schema: z.ZodObject<any, any, any>;
    onUpdate: (field: UpdatableField, data: any) => void;
    children: React.ReactNode;
}

function UpdateCard({ title, field, value, schema, onUpdate, children }: UpdateCardProps) {
    const { t } = useTranslation();
    const [isOpen, setIsOpen] = useState(false);
    const form = useForm({
        resolver: zodResolver(schema),
        defaultValues: { [field]: '' }
    });

    const onSubmit = (data: any) => {
        onUpdate(field, data);
        setIsOpen(false);
        form.reset();
    };
    
    return (
         <Card>
            <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <Label>{title}</Label>
                    <p className="text-lg font-semibold">{value}</p>
                </div>
                 <Dialog open={isOpen} onOpenChange={setIsOpen}>
                    <DialogTrigger asChild>
                         <Button variant="outline">{t('myDetails.updateDialog.changeButton')}</Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>{t('myDetails.updateDialog.title', { field: title.toLowerCase() })}</DialogTitle>
                            <DialogDescriptionComponent>{t('myDetails.updateDialog.description', { field: title.toLowerCase() })}</DialogDescriptionComponent>
                        </DialogHeader>
                        <FormProvider {...form}>
                            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                                {children}
                                <DialogFooter>
                                    <DialogClose asChild>
                                        <Button type="button" variant="ghost">{t('myDetails.updateDialog.cancelButton')}</Button>
                                    </DialogClose>
                                    <Button type="submit">{t('myDetails.updateDialog.saveButton')}</Button>
                                </DialogFooter>
                            </form>
                        </FormProvider>
                    </DialogContent>
                </Dialog>
            </CardHeader>
        </Card>
    );
}

function ControlledInput({ name, ...props }: { name: string } & React.ComponentProps<typeof Input>) {
    return (
        <FormField
            name={name}
            render={({ field }) => (
                <FormItem>
                    <FormControl>
                        <Input {...field} {...props} />
                    </FormControl>
                    <FormMessage />
                </FormItem>
            )}
        />
    )
}

function SupportCard() {
    const { t } = useTranslation();
    const [isOpen, setIsOpen] = useState(false);
    const { toast } = useToast();
    const form = useForm({
        resolver: zodResolver(supportSchema),
        defaultValues: { name: '', email: '', message: '' }
    });

    const onSubmit = (data: any) => {
        toast({
            title: t('myDetails.support.toast.title'),
            description: t('myDetails.support.toast.description'),
        });
        setIsOpen(false);
        form.reset();
    };

    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between">
                <div className="flex items-center gap-4">
                    <LifeBuoy className="h-6 w-6 text-primary" />
                    <div>
                        <Label>{t('accountMenu.support')}</Label>
                        <p className="text-sm text-muted-foreground">{t('myDetails.support.description')}</p>
                    </div>
                </div>
                <Dialog open={isOpen} onOpenChange={setIsOpen}>
                    <DialogTrigger asChild>
                        <Button variant="outline">{t('myDetails.support.button')}</Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>{t('myDetails.support.title')}</DialogTitle>
                            <DialogDescriptionComponent>{t('myDetails.support.formDescription')}</DialogDescriptionComponent>
                        </DialogHeader>
                        <FormProvider {...form}>
                            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                                <ControlledInput name="name" placeholder={t('myDetails.support.namePlaceholder')} />
                                <ControlledInput name="email" type="email" placeholder={t('myDetails.support.emailPlaceholder')} />
                                <FormField
                                    name="message"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormControl>
                                                <Textarea placeholder={t('myDetails.support.messagePlaceholder')} {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <DialogFooter>
                                    <DialogClose asChild>
                                        <Button type="button" variant="ghost">{t('myDetails.updateDialog.cancelButton')}</Button>
                                    </DialogClose>
                                    <Button type="submit">{t('myDetails.support.submitButton')}</Button>
                                </DialogFooter>
                            </form>
                        </FormProvider>
                    </DialogContent>
                </Dialog>
            </CardHeader>
        </Card>
    );
}

