
'use client'

import React, { useState } from 'react';
import * as LucideIcons from 'lucide-react';
import { useSwipeable } from 'react-swipeable';
import { DashboardHeader } from '@/components/dashboard/header';
import { StatCard } from '@/components/dashboard/stat-card';
import { InvestmentForm } from '@/components/dashboard/investment-form';
import { AnalyticsChart } from '@/components/dashboard/analytics-chart';
import { BottomNav } from '@/components/dashboard/bottom-nav';
import { stats as initialStats } from '@/lib/data';
import { useTranslation } from '@/hooks/use-translation';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PaymentHistory } from '@/components/dashboard/payment-history';

const TABS = ['overview', 'analytics', 'invest'];

export default function Home() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState(TABS[0]);
  
  const STAT_ORDER = [
    'Available',
    'Spent',
    'Total members',
    'Total investment',
    'Subscribed members',
    'My total share',
  ];

  const orderedStats = STAT_ORDER.map(originalTitle => {
    const stat = initialStats.find(s => s.originalTitle === originalTitle);
    if (!stat) return null;
    return {
      ...stat,
      title: t(`stats.${stat.originalTitle.toLowerCase().replace(/ /g, '')}`),
    };
  }).filter((stat): stat is typeof stat & { originalTitle: string; value: string | number; change: string; icon: keyof typeof LucideIcons } => stat !== null);


  const handleSwipe = (direction: 'left' | 'right') => {
    const currentIndex = TABS.indexOf(activeTab);
    if (direction === 'left') {
      const nextIndex = (currentIndex + 1) % TABS.length;
      setActiveTab(TABS[nextIndex]);
    } else {
      const nextIndex = (currentIndex - 1 + TABS.length) % TABS.length;
      setActiveTab(TABS[nextIndex]);
    }
  };

  const swipeHandlers = useSwipeable({
    onSwipedLeft: () => handleSwipe('left'),
    onSwipedRight: () => handleSwipe('right'),
    preventScrollOnSwipe: true,
    trackMouse: true,
  });

  return (
    <div className="flex min-h-screen w-full flex-col">
      <DashboardHeader />
      <main className="flex flex-1 flex-col items-center gap-6 bg-background p-4 sm:p-6 md:p-8 mb-16">
        <div className="w-full max-w-4xl">
           <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">{t('home.tabs.overview')}</TabsTrigger>
              <TabsTrigger value="analytics">{t('home.tabs.analytics')}</TabsTrigger>
              <TabsTrigger value="invest">{t('home.tabs.invest')}</TabsTrigger>
            </TabsList>
            <div {...swipeHandlers}>
                <TabsContent value="overview" className="mt-6">
                    <div className="grid grid-cols-2 gap-4 md:grid-cols-3 md:gap-6 lg:grid-cols-3">
                        {orderedStats.map((stat) => (
                            <StatCard
                            key={stat.originalTitle}
                            title={stat.title}
                            value={stat.value}
                            change={stat.change}
                            icon={stat.icon}
                            />
                        ))}
                    </div>
                </TabsContent>
                <TabsContent value="analytics" className="mt-6">
                    <AnalyticsChart title={t('analyticsChart.investmentTitle')} description={t('analyticsChart.investmentDescription')} dataKey="investment" />
                </TabsContent>
                <TabsContent value="invest" className="mt-6 flex flex-col items-center gap-6">
                    <div className="w-full max-w-md">
                        <InvestmentForm />
                    </div>
                    <div className="w-full max-w-md">
                        <PaymentHistory />
                    </div>
                </TabsContent>
            </div>
          </Tabs>
        </div>
      </main>
      <BottomNav />
    </div>
  );
}
