
'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Eye, EyeOff } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useTranslation } from '@/hooks/use-translation';
import { SupportDialog } from '@/components/auth/support-dialog';
import { members } from '@/app/members/page';

const emailLoginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
});

const phoneLoginSchema = z.object({
    phoneNumber: z.string().min(1, 'Phone number is required'),
    password: z.string().min(1, 'Password is required'),
});

const codeLoginSchema = z.object({
    loginIdentifier: z.string().min(1, 'Email or phone number is required'),
    confirmationCode: z.string().length(6, 'Code must be 6 digits'),
});

type EmailLoginFormValues = z.infer<typeof emailLoginSchema>;
type PhoneLoginFormValues = z.infer<typeof phoneLoginSchema>;
type CodeLoginFormValues = z.infer<typeof codeLoginSchema>;

const MOCK_CODE = "123456";

export default function LoginPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { t } = useTranslation();
  const [loginMode, setLoginMode] = useState<'password' | 'code'>('password');
  const [activeTab, setActiveTab] = useState<'email' | 'phone'>('email');

  const emailForm = useForm<EmailLoginFormValues>({
    resolver: zodResolver(emailLoginSchema),
    defaultValues: { email: '', password: '' },
  });

  const phoneForm = useForm<PhoneLoginFormValues>({
    resolver: zodResolver(phoneLoginSchema),
    defaultValues: { phoneNumber: '', password: '' },
  });

  const codeForm = useForm<CodeLoginFormValues>({
    resolver: zodResolver(codeLoginSchema),
     defaultValues: { loginIdentifier: '', confirmationCode: '' },
  });

  const onEmailSubmit = (data: EmailLoginFormValues) => {
    const user = members.find(m => m.email === data.email && m.password === data.password);
    if (user) {
      toast({
        title: t('login.toast.success.title'),
        description: t('login.toast.success.description'),
      });
      router.push('/');
    } else {
      toast({
        variant: 'destructive',
        title: t('login.toast.failure.title'),
        description: t('login.toast.failure.description'),
      });
    }
  };
  
  const onPhoneSubmit = (data: PhoneLoginFormValues) => {
    const user = members.find(m => m.phoneNumber === data.phoneNumber && m.password === data.password);
    if (user) {
      toast({
        title: t('login.toast.success.title'),
        description: t('login.toast.success.description'),
      });
      router.push('/');
    } else {
      toast({
        variant: 'destructive',
        title: t('login.toast.failure.title'),
        description: t('login.toast.failure.description'),
      });
    }
  };

  const onCodeSubmit = (data: CodeLoginFormValues) => {
      const user = members.find(m => m.email === data.loginIdentifier || m.phoneNumber === data.loginIdentifier);

      if (user && data.confirmationCode === MOCK_CODE) {
           toast({
                title: t('login.toast.success.title'),
                description: t('login.toast.success.description'),
            });
            router.push('/');
      } else {
          toast({
            variant: 'destructive',
            title: t('login.toast.failure.title'),
            description: t('login.toast.failure.descriptionCode'),
        });
      }
  }

  const handleSendCode = () => {
    const loginIdentifier = codeForm.getValues('loginIdentifier');
    const user = members.find(m => m.email === loginIdentifier || m.phoneNumber === loginIdentifier);

    if (user) {
         const code = MOCK_CODE;
         toast({
            title: t('myDetails.sendCodeToast.title'),
            description: t('myDetails.sendCodeToast.descriptionWithCode', { type: activeTab, code: code }),
         });
    } else {
        toast({
            variant: 'destructive',
            title: t('login.forgotPassword.toast.notFound.title'),
            description: t('login.forgotPassword.toast.notFound.description'),
        });
    }
  }

  return (
    <div className="flex min-h-screen w-full flex-col items-center justify-center bg-background p-4">
      <Card className="w-full max-w-sm">
        <CardHeader>
          <CardTitle className="text-2xl">{t('login.title')}</CardTitle>
          <CardDescription>{t('login.description')}</CardDescription>
        </CardHeader>
        <CardContent>
            <Tabs defaultValue={activeTab} onValueChange={(val) => setActiveTab(val as 'email' | 'phone')} className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="email">{t('login.tabs.email')}</TabsTrigger>
                    <TabsTrigger value="phone">{t('login.tabs.phone')}</TabsTrigger>
                </TabsList>

                {loginMode === 'password' ? (
                    <>
                        <TabsContent value="email">
                            <Form {...emailForm}>
                                <form onSubmit={emailForm.handleSubmit(onEmailSubmit)} className="space-y-4 pt-4">
                                <FormField
                                    control={emailForm.control}
                                    name="email"
                                    render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>{t('myDetails.email')}</FormLabel>
                                        <FormControl>
                                        <Input type="email" placeholder="m@example.com" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                    )}
                                />
                                <PasswordField form={emailForm} />
                                <Button type="submit" className="w-full">
                                    {t('login.button')}
                                </Button>
                                </form>
                            </Form>
                        </TabsContent>
                        <TabsContent value="phone">
                            <Form {...phoneForm}>
                                <form onSubmit={phoneForm.handleSubmit(onPhoneSubmit)} className="space-y-4 pt-4">
                                <FormField
                                    control={phoneForm.control}
                                    name="phoneNumber"
                                    render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>{t('myDetails.phoneNumber')}</FormLabel>
                                        <FormControl>
                                        <Input type="tel" placeholder="+1234567890" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                    )}
                                />
                                <PasswordField form={phoneForm} />
                                <Button type="submit" className="w-full">
                                    {t('login.button')}
                                </Button>
                                </form>
                            </Form>
                        </TabsContent>
                         <div className="text-center text-sm pt-4">
                            <button onClick={() => setLoginMode('code')} className="font-semibold text-primary hover:underline">{t('login.forgotPassword.link')}</button>
                        </div>
                    </>
                ) : (
                    <TabsContent value={activeTab} forceMount>
                        <Form {...codeForm}>
                            <form onSubmit={codeForm.handleSubmit(onCodeSubmit)} className="space-y-4 pt-4">
                               <FormField
                                    control={codeForm.control}
                                    name="loginIdentifier"
                                    render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>{activeTab === 'email' ? t('myDetails.email') : t('myDetails.phoneNumber')}</FormLabel>
                                        <FormControl>
                                            <Input 
                                                type={activeTab === 'email' ? 'email' : 'tel'} 
                                                placeholder={activeTab === 'email' ? 'm@example.com' : '+1234567890'} 
                                                {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                    )}
                                />
                                <Button type="button" variant="outline" size="sm" onClick={handleSendCode} className="w-full">{t('login.forgotPassword.sendCodeButton')}</Button>
                                <FormField
                                    control={codeForm.control}
                                    name="confirmationCode"
                                    render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>{t('login.forgotPassword.codeLabel')}</FormLabel>
                                        <FormControl>
                                        <Input type="text" maxLength={6} placeholder="_ _ _ _ _ _" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                    )}
                                />
                                <Button type="submit" className="w-full">{t('login.button')}</Button>
                            </form>
                        </Form>
                        <div className="text-center text-sm pt-4">
                            <button onClick={() => setLoginMode('password')} className="font-semibold text-primary hover:underline">{t('login.forgotPassword.loginWithPasswordLink')}</button>
                        </div>
                    </TabsContent>
                )}
            </Tabs>
        </CardContent>
        <CardFooter className="flex flex-col items-center gap-2 text-sm">
            <p>{t('login.noAccount')} <Link href="/register" className="font-semibold text-primary hover:underline">{t('login.registerLink')}</Link></p>
            <SupportDialog />
        </CardFooter>
      </Card>
    </div>
  );
}

function PasswordField({ form }: { form: any }) {
    const { t } = useTranslation();
    const [showPassword, setShowPassword] = useState(false);
    return (
        <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
                <FormItem>
                <FormLabel>{t('myDetails.password')}</FormLabel>
                <FormControl>
                    <div className="relative">
                    <Input type={showPassword ? 'text' : 'password'} {...field} />
                    <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute inset-y-0 right-0 h-full px-3"
                        onClick={() => setShowPassword(!showPassword)}
                    >
                        {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </Button>
                    </div>
                </FormControl>
                <FormMessage />
                </FormItem>
            )}
        />
    )
}

    