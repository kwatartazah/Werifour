
'use client';

import React, { useState, useEffect } from 'react';
import { useSwipeable } from 'react-swipeable';
import { DashboardHeader } from '@/components/dashboard/header';
import { BottomNav } from '@/components/dashboard/bottom-nav';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChartComponent } from '@/components/dashboard/pie-chart';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { NewsFeed, NewsItem } from '@/components/dashboard/news-feed';
import { TaskCard } from '@/components/dashboard/task-card';
import { Plus, AlignLeft, AlignRight } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { useTranslation } from '@/hooks/use-translation';

const initialNewsItems: NewsItem[] = [
    {
      id: 1,
      author: 'USR-011',
      content: 'Great news! We have secured funding for the new well in the northern village. Construction will begin next month. Thanks to all who contributed!',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      likes: 150,
      dislikes: 5,
      textAlign: 'left',
    },
    {
      id: 2,
      author: 'USR-012',
      content: 'Reminder: The mobile health clinic will be visiting the eastern region this weekend. Free check-ups and vaccinations will be available.',
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
      likes: 89,
      dislikes: 2,
      textAlign: 'left',
    },
    {
      id: 3,
      author: 'USR-013',
      content: 'School supply distribution was a success! Over 500 children received new books and materials. A huge thank you to our volunteers.',
      timestamp: new Date(Date.now() - 23 * 60 * 60 * 1000), // 23 hours ago
      likes: 320,
      dislikes: 10,
      textAlign: 'right',
    },
    {
      id: 4,
      author: 'USR-014',
      content: 'This post is about to expire and will be removed soon.',
      timestamp: new Date(Date.now() - 23 * 60 * 60 * 1000 - 59 * 60 * 1000 - 50 * 1000), // 23h 59m 50s ago
      likes: 10,
      dislikes: 1,
      textAlign: 'left',
    }
  ];

const tasks = [
  {
    description: 'Review the latest community project proposal and provide feedback on the attached document.',
    link: '#',
  },
  {
    description: 'Sign up for a volunteer slot for the upcoming community clean-up day. Your help is greatly appreciated!',
    link: '#',
  },
  {
    description: 'Complete the annual member survey to help us improve our services and programs for the coming year.',
    link: '#',
  },
];

const TABS = ['opinions', 'tasks', 'vote'];

export default function ActionsPage() {
  const totalMembers = 10254;
  const [yesVotes, setYesVotes] = useState(4200);
  const [noVotes, setNoVotes] = useState(1500);
  const [voted, setVoted] = useState<'yes' | 'no' | null>(null);
  const [isCreatePostOpen, setCreatePostOpen] = useState(false);
  const [newsItems, setNewsItems] = useState(initialNewsItems);
  const [newPostContent, setNewPostContent] = useState('');
  const [textAlign, setTextAlign] = useState<'left' | 'right'>('left');
  const { toast } = useToast();
  const { t, direction, setLanguage } = useTranslation();
  const [activeTab, setActiveTab] = useState(TABS[0]);


  const notVoted = totalMembers - yesVotes - noVotes;

  const voteData = [
    { name: 'Yes', value: yesVotes, fill: '#00bf63' },
    { name: 'No', value: noVotes, fill: 'hsl(var(--destructive))' },
    { name: 'Not Voted', value: notVoted, fill: 'hsl(var(--muted))' },
  ];
  
  const handleVote = (vote: 'yes' | 'no') => {
    if (voted === vote) {
      if (vote === 'yes') {
        setYesVotes(yesVotes - 1);
      } else {
        setNoVotes(noVotes - 1);
      }
      setVoted(null);
    } else if (voted === null) {
      if (vote === 'yes') {
        setYesVotes(yesVotes + 1);
      } else {
        setNoVotes(noVotes + 1);
      }
      setVoted(vote);
    }
  };

  const handleCreatePost = () => {
    const userHasPost = newsItems.some(item => item.author === 'USR-ME');
    if (userHasPost) {
        toast({
            variant: "destructive",
            title: t('actions.news.toast.limit.title'),
            description: t('actions.news.toast.limit.description'),
        });
        return;
    }

    if (newPostContent.trim()) {
        const newPost: NewsItem = {
            id: Date.now(),
            author: 'USR-ME', // Placeholder for current user
            content: newPostContent,
            timestamp: new Date(),
            likes: 0,
            dislikes: 0,
            textAlign: textAlign,
        };
        setNewsItems(prevItems => [newPost, ...prevItems]);
        setNewPostContent('');
        setTextAlign('left');
        setCreatePostOpen(false);
    }
  }

  const handleSwipe = (direction: 'left' | 'right') => {
    const currentIndex = TABS.indexOf(activeTab);
    if (direction === 'left') {
      const nextIndex = (currentIndex + 1) % TABS.length;
      setActiveTab(TABS[nextIndex]);
    } else {
      const nextIndex = (currentIndex - 1 + TABS.length) % TABS.length;
      setActiveTab(TABS[nextIndex]);
    }
  };

  const swipeHandlers = useSwipeable({
    onSwipedLeft: () => handleSwipe('left'),
    onSwipedRight: () => handleSwipe('right'),
    preventScrollOnSwipe: true,
    trackMouse: true,
  });

  return (
    <div className="flex min-h-screen w-full flex-col">
      <DashboardHeader />
      <main className="flex flex-1 flex-col items-center gap-6 bg-background p-4 sm:p-6 md:p-8 mb-16">
        <div className="w-full max-w-md">
           <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="opinions">{t('actions.tabs.opinions')}</TabsTrigger>
              <TabsTrigger value="tasks">{t('actions.tabs.tasks')}</TabsTrigger>
              <TabsTrigger value="vote">{t('actions.tabs.vote')}</TabsTrigger>
            </TabsList>
            <div {...swipeHandlers}>
                <TabsContent value="opinions" className="relative space-y-6 mt-6">
                  <NewsFeed newsItems={newsItems} setNewsItems={setNewsItems} />
                  <Button onClick={() => setCreatePostOpen(true)} className="fixed bottom-24 right-6 h-14 w-14 rounded-full shadow-lg" size="icon">
                      <Plus className="h-6 w-6" />
                  </Button>
                </TabsContent>
                <TabsContent value="tasks" className="space-y-6 mt-6">
                  {tasks.map((task, index) => (
                    <TaskCard key={index} description={task.description} link={task.link} />
                  ))}
                </TabsContent>
                <TabsContent value="vote" className="space-y-6 mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>{t('actions.vote.title')}</CardTitle>
                      <CardDescription>
                        {t('actions.vote.description', { totalMembers: totalMembers.toLocaleString() })}
                      </CardDescription>
                    </CardHeader>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>{t('actions.vote.resultsTitle')}</CardTitle>
                      <CardDescription>{t('actions.vote.resultsDescription')}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <PieChartComponent 
                        data={voteData}
                        dataKey="value"
                        nameKey="name"
                        hasCard={false}
                      />
                    </CardContent>
                    <CardFooter className="flex justify-end gap-4">
                      <Button 
                        size="lg" 
                        className="text-white text-lg px-8 py-4"
                        style={{ backgroundColor: '#00bf63' }}
                        onClick={() => handleVote('yes')}
                        disabled={voted === 'no'}
                      >
                        {t('actions.vote.yes')}
                      </Button>
                      <Button 
                        size="lg" 
                        variant="destructive" 
                        className="text-lg px-8 py-4"
                        onClick={() => handleVote('no')}
                        disabled={voted === 'yes'}
                      >
                        {t('actions.vote.no')}
                      </Button>
                    </CardFooter>
                  </Card>
                </TabsContent>
            </div>
          </Tabs>
        </div>
      </main>
      <BottomNav />

      <Dialog open={isCreatePostOpen} onOpenChange={setCreatePostOpen}>
        <DialogContent>
            <DialogHeader>
                <DialogTitle>{t('actions.news.create.title')}</DialogTitle>
                <DialogDescription>
                    {t('actions.news.create.description')}
                </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="post-content">{t('actions.news.create.messageLabel')}</Label>
                      <div className="flex gap-1">
                          <Button 
                              variant={textAlign === 'left' ? 'secondary' : 'ghost'} 
                              size="icon" 
                              className="h-6 w-6" 
                              onClick={() => {
                                setTextAlign('left');
                                setLanguage('en');
                              }}
                          >
                              <AlignLeft className="h-4 w-4" />
                          </Button>
                          <Button 
                              variant={textAlign === 'right' ? 'secondary' : 'ghost'} 
                              size="icon" 
                              className="h-6 w-6"
                              onClick={() => {
                                setTextAlign('right');
                                setLanguage('ar');
                              }}
                          >
                              <AlignRight className="h-4 w-4" />
                          </Button>
                      </div>
                    </div>
                    <div className="relative">
                        <Textarea 
                            id="post-content"
                            value={newPostContent}
                            onChange={(e) => setNewPostContent(e.target.value)}
                            maxLength={300}
                            className={cn("min-h-[120px] resize-none")}
                            dir={direction}
                        />
                    </div>
                    <div className="text-right text-sm text-muted-foreground">
                        {newPostContent.length} / 300
                    </div>
                </div>
            </div>
            <DialogFooter>
                <Button variant="ghost" onClick={() => setCreatePostOpen(false)}>{t('actions.news.create.cancel')}</Button>
                <Button onClick={handleCreatePost} disabled={!newPostContent.trim()}>{t('actions.news.create.post')}</Button>
            </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
}
